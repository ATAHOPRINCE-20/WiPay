System.register(["./index-legacy-Bsr9WpUR.js"],function(e,t){"use strict";var s;return{setters:[function(e){s=e.c}],execute:function(){
/**
       * @license lucide-react v0.447.0 - ISC
       *
       * This source code is licensed under the ISC license.
       * See the LICENSE file in the root directory of this source tree.
       */
e("P",s("Plus",[["path",{d:"M5 12h14",key:"1ays0h"}],["path",{d:"M12 5v14",key:"s699le"}]]))}}});
