System.register(["./index-legacy-Bsr9WpUR.js"],function(e,t){"use strict";var n;return{setters:[function(e){n=e.c}],execute:function(){
/**
       * @license lucide-react v0.447.0 - ISC
       *
       * This source code is licensed under the ISC license.
       * See the LICENSE file in the root directory of this source tree.
       */
e("C",n("ChevronDown",[["path",{d:"m6 9 6 6 6-6",key:"qrunsl"}]]))}}});
