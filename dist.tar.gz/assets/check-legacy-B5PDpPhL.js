System.register(["./index-legacy-Bsr9WpUR.js"],function(e,t){"use strict";var c;return{setters:[function(e){c=e.c}],execute:function(){
/**
			 * @license lucide-react v0.447.0 - ISC
			 *
			 * This source code is licensed under the ISC license.
			 * See the LICENSE file in the root directory of this source tree.
			 */
e("C",c("Check",[["path",{d:"M20 6 9 17l-5-5",key:"1gmf2c"}]]))}}});
