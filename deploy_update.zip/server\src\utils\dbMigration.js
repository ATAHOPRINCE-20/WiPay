const db = require('../config/db');

async function runPendingMigrations() {
    console.log('Checking for pending database migrations...');
    try {
        // Migration 1: Add is_active to packages
        const addColumnQuery = `
            ALTER TABLE packages
            ADD COLUMN is_active BOOLEAN NOT NULL DEFAULT 1;
        `;

        await db.query(addColumnQuery);
        console.log('Migration Success: Added is_active column to packages table.');
    } catch (err) {
        if (err.code === 'ER_DUP_FIELDNAME') {
            console.log('Migration Info: is_active column already exists.');
        } else {
            console.error('Migration Error:', err);
        }
    }

    try {
        // Migration 2: Create routers table
        const createRoutersTableQuery = `
            CREATE TABLE IF NOT EXISTS routers (
                id INT AUTO_INCREMENT PRIMARY KEY,
                admin_id INT NOT NULL,
                name VARCHAR(255) NOT NULL,
                mikhmon_url TEXT NOT NULL,
                created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
                FOREIGN KEY (admin_id) REFERENCES admins(id) ON DELETE CASCADE
            );
        `;
        await db.query(createRoutersTableQuery);
        console.log('Migration Success: Routers table checked/created.');
    } catch (err) {
        console.error('Migration Error (Routers Table):', err);
    }

    try {
        // Migration 3: Add router_id to transactions
        const addRouterColumnQuery = `
            ALTER TABLE transactions
            ADD COLUMN router_id INT DEFAULT NULL;
        `;
        await db.query(addRouterColumnQuery);
        console.log('Migration Success: Added router_id to transactions table.');
    } catch (err) {
        if (err.code === 'ER_DUP_FIELDNAME') {
            console.log('Migration Info: router_id column already exists in transactions.');
        } else {
            console.error('Migration Error (Transactions router_id):', err);
        }
    }

    try {
        // Migration 4: Allow NULL for package_id in transactions (for safe deletion)
        const alterPackageIdQuery = `
            ALTER TABLE transactions
            MODIFY COLUMN package_id INT NULL;
        `;
        await db.query(alterPackageIdQuery);
        console.log('Migration Success: transactions.package_id is now nullable.');
    } catch (err) {
        console.error('Migration Error (Transactions package_id):', err);
    }

    try {
        // Migration 5: Add role to admins
        const addRoleQuery = `
            ALTER TABLE admins
            ADD COLUMN role ENUM('admin', 'super_admin') DEFAULT 'admin';
        `;
        await db.query(addRoleQuery);
        console.log('Migration Success: Added role column to admins table.');
    } catch (err) {
        if (err.code === 'ER_DUP_FIELDNAME') {
            console.log('Migration Info: role column already exists in admins.');
        } else {
            console.error('Migration Error (Admins role):', err);
        }
    }

    try {
        // Migration 6: Add billing_type to admins
        const addBillingTypeQuery = `
            ALTER TABLE admins
            ADD COLUMN billing_type ENUM('commission', 'subscription') DEFAULT 'commission' AFTER role;
        `;
        await db.query(addBillingTypeQuery);
        console.log('Migration Success: Added billing_type column to admins table.');
    } catch (err) {
        if (err.code === 'ER_DUP_FIELDNAME') {
            console.log('Migration Info: billing_type column already exists in admins.');
        } else {
            console.error('Migration Error (Admins billing_type):', err);
        }
    }

    try {
        // Migration 7: Add subscription_expiry to admins
        const addSubExpiryQuery = `
            ALTER TABLE admins
            ADD COLUMN subscription_expiry DATETIME DEFAULT NULL AFTER billing_type;
        `;
        await db.query(addSubExpiryQuery);
        console.log('Migration Success: Added subscription_expiry column to admins table.');
    } catch (err) {
        if (err.code === 'ER_DUP_FIELDNAME') {
            console.log('Migration Info: subscription_expiry column already exists in admins.');
        } else {
            console.error('Migration Error (Admins subscription_expiry):', err);
        }
    }

    try {
        // Migration 8: Router isolation (categories, packages, vouchers)
        const columnExists = async (table, column) => {
            const [rows] = await db.query(`SHOW COLUMNS FROM ${table} LIKE '${column}'`);
            return rows.length > 0;
        };

        if (!(await columnExists('categories', 'router_id'))) {
            console.log("Migration: Adding router_id to categories...");
            await db.query("ALTER TABLE categories ADD COLUMN router_id INT NULL");
        }

        if (!(await columnExists('packages', 'router_id'))) {
            console.log("Migration: Adding router_id to packages...");
            await db.query("ALTER TABLE packages ADD COLUMN router_id INT NULL");
            await db.query("ALTER TABLE packages ADD CONSTRAINT fk_pkg_router FOREIGN KEY (router_id) REFERENCES routers(id) ON DELETE SET NULL");
        }

        if (!(await columnExists('vouchers', 'router_id'))) {
            console.log("Migration: Adding router_id to vouchers...");
            await db.query("ALTER TABLE vouchers ADD COLUMN router_id INT NULL");
            await db.query("ALTER TABLE vouchers ADD CONSTRAINT fk_voucher_router FOREIGN KEY (router_id) REFERENCES routers(id) ON DELETE SET NULL");
        }

        console.log('Migration Success: Router isolation columns checked/added.');
    } catch (err) {
        console.error('Migration Error (Router Isolation):', err);
    }

    try {
        // Migration 9: Add RADIUS and VPN columns to routers, and make mikhmon_url nullable
        const columnExists = async (table, column) => {
            const [rows] = await db.query(`SHOW COLUMNS FROM ${table} LIKE '${column}'`);
            return rows.length > 0;
        };

        if (await columnExists('routers', 'mikhmon_url')) {
            await db.query("ALTER TABLE routers MODIFY COLUMN mikhmon_url TEXT NULL");
        }

        if (!(await columnExists('routers', 'ip_address'))) {
            console.log("Migration: Adding ip_address to routers...");
            await db.query("ALTER TABLE routers ADD COLUMN ip_address VARCHAR(45) DEFAULT NULL");
        }

        if (!(await columnExists('routers', 'radius_secret'))) {
            console.log("Migration: Adding radius_secret to routers...");
            await db.query("ALTER TABLE routers ADD COLUMN radius_secret VARCHAR(255) DEFAULT NULL");
        }

        if (!(await columnExists('routers', 'wg_private_key'))) {
            console.log("Migration: Adding wg_private_key to routers...");
            await db.query("ALTER TABLE routers ADD COLUMN wg_private_key VARCHAR(64) DEFAULT NULL");
        }

        if (!(await columnExists('routers', 'wg_public_key'))) {
            console.log("Migration: Adding wg_public_key to routers...");
            await db.query("ALTER TABLE routers ADD COLUMN wg_public_key VARCHAR(64) DEFAULT NULL");
        }

        console.log('Migration Success: RADIUS/VPN columns checked/added to routers.');
    } catch (err) {
        console.error('Migration Error (Router RADIUS/VPN Columns):', err);
    }

    try {
        // Migration 10: Modify admins role and add parent_id, portal_dns, portal_logo, portal_welcome_msg, terms_text columns
        const columnExists = async (table, column) => {
            const [rows] = await db.query(`SHOW COLUMNS FROM ${table} LIKE '${column}'`);
            return rows.length > 0;
        };

        console.log("Migration: Checking/modifying admins.role ENUM...");
        await db.query("ALTER TABLE admins MODIFY COLUMN role ENUM('admin', 'super_admin', 'agent') DEFAULT 'admin'");

        if (!(await columnExists('admins', 'parent_id'))) {
            console.log("Migration: Adding parent_id to admins...");
            await db.query("ALTER TABLE admins ADD COLUMN parent_id INT DEFAULT NULL");
            await db.query("ALTER TABLE admins ADD CONSTRAINT fk_admin_parent FOREIGN KEY (parent_id) REFERENCES admins(id) ON DELETE CASCADE");
        }

        if (!(await columnExists('admins', 'portal_dns'))) {
            console.log("Migration: Adding portal_dns to admins...");
            await db.query("ALTER TABLE admins ADD COLUMN portal_dns VARCHAR(255) DEFAULT NULL");
        }

        if (!(await columnExists('admins', 'portal_logo'))) {
            console.log("Migration: Adding portal_logo to admins...");
            await db.query("ALTER TABLE admins ADD COLUMN portal_logo VARCHAR(255) DEFAULT NULL");
        }

        if (!(await columnExists('admins', 'portal_welcome_msg'))) {
            console.log("Migration: Adding portal_welcome_msg to admins...");
            await db.query("ALTER TABLE admins ADD COLUMN portal_welcome_msg VARCHAR(255) DEFAULT NULL");
        }

        if (!(await columnExists('admins', 'terms_text'))) {
            console.log("Migration: Adding terms_text to admins...");
            await db.query("ALTER TABLE admins ADD COLUMN terms_text TEXT DEFAULT NULL");
        }

        // Create portal_ads table
        console.log("Migration: Checking/creating portal_ads table...");
        await db.query(`
            CREATE TABLE IF NOT EXISTS portal_ads (
                id INT AUTO_INCREMENT PRIMARY KEY,
                admin_id INT NOT NULL,
                title VARCHAR(255) NOT NULL,
                image_url VARCHAR(255) NOT NULL,
                link_url VARCHAR(255) DEFAULT NULL,
                is_active BOOLEAN DEFAULT 1,
                created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
                FOREIGN KEY (admin_id) REFERENCES admins(id) ON DELETE CASCADE
            )
        `);

        // Add validity_unit and validity_minutes to packages table if missing
        if (!(await columnExists('packages', 'validity_unit'))) {
            console.log("Migration: Adding validity_unit to packages...");
            await db.query("ALTER TABLE packages ADD COLUMN validity_unit ENUM('minutes', 'hours') DEFAULT 'hours'");
        }

        if (!(await columnExists('packages', 'validity_minutes'))) {
            console.log("Migration: Adding validity_minutes to packages...");
            await db.query("ALTER TABLE packages ADD COLUMN validity_minutes INT DEFAULT NULL");
        }

        console.log('Migration Success: Admins role, parent_id, portal settings and portal_ads table checked/created.');
    } catch (err) {
        console.error('Migration Error (Portal Settings & Ads):', err);
    }

    try {
        // Migration 11: Add business_name, business_phone, portal_slug, referral_code to admins
        const columnExists = async (table, column) => {
            const [rows] = await db.query(`SHOW COLUMNS FROM ${table} LIKE '${column}'`);
            return rows.length > 0;
        };

        if (!(await columnExists('admins', 'business_name'))) {
            console.log("Migration: Adding business_name to admins...");
            await db.query("ALTER TABLE admins ADD COLUMN business_name VARCHAR(255) DEFAULT 'UGPAY'");
        }

        if (!(await columnExists('admins', 'business_phone'))) {
            console.log("Migration: Adding business_phone to admins...");
            await db.query("ALTER TABLE admins ADD COLUMN business_phone VARCHAR(50) DEFAULT NULL");
        }

        if (!(await columnExists('admins', 'portal_slug'))) {
            console.log("Migration: Adding portal_slug to admins...");
            await db.query("ALTER TABLE admins ADD COLUMN portal_slug VARCHAR(50) UNIQUE DEFAULT NULL");
        }

        if (!(await columnExists('admins', 'referral_code'))) {
            console.log("Migration: Adding referral_code to admins...");
            await db.query("ALTER TABLE admins ADD COLUMN referral_code VARCHAR(50) DEFAULT NULL");
        }

        if (!(await columnExists('admins', 'email'))) {
            console.log("Migration: Adding email to admins...");
            await db.query("ALTER TABLE admins ADD COLUMN email VARCHAR(255) DEFAULT NULL");
        }

        // Generate unique random portal_slug for any existing admins that don't have one
        const [admins] = await db.query("SELECT id FROM admins WHERE portal_slug IS NULL OR portal_slug = '' OR portal_slug = 'default'");
        if (admins.length > 0) {
            console.log(`Migration: Generating unique portal_slug for ${admins.length} admins...`);
            const crypto = require('crypto');
            for (const admin of admins) {
                const slug = 'wp_' + crypto.randomBytes(6).toString('hex');
                await db.query("UPDATE admins SET portal_slug = ? WHERE id = ?", [slug, admin.id]);
            }
        }

        console.log('Migration Success: Admins business details and portal_slug checked/created.');
    } catch (err) {
        console.error('Migration Error (Business details & portal_slug):', err);
    }

    try {
        // Migration 12: Ensure withdrawals, admin_subscriptions, and sms_logs tables exist
        await db.query(`
            CREATE TABLE IF NOT EXISTS withdrawals (
                id INT AUTO_INCREMENT PRIMARY KEY,
                admin_id INT NOT NULL,
                amount DECIMAL(10,2) NOT NULL,
                phone_number VARCHAR(50) DEFAULT NULL,
                status ENUM('pending', 'success', 'failed') DEFAULT 'pending',
                reference VARCHAR(100) UNIQUE DEFAULT NULL,
                created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
                FOREIGN KEY (admin_id) REFERENCES admins(id) ON DELETE CASCADE
            ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;
        `);

        await db.query(`
            CREATE TABLE IF NOT EXISTS admin_subscriptions (
                id INT AUTO_INCREMENT PRIMARY KEY,
                admin_id INT NOT NULL,
                amount DECIMAL(10,2) NOT NULL,
                months INT NOT NULL DEFAULT 1,
                phone_number VARCHAR(50) DEFAULT NULL,
                status ENUM('pending', 'success', 'failed') DEFAULT 'pending',
                reference VARCHAR(100) UNIQUE DEFAULT NULL,
                created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
                FOREIGN KEY (admin_id) REFERENCES admins(id) ON DELETE CASCADE
            ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;
        `);

        await db.query(`
            CREATE TABLE IF NOT EXISTS sms_logs (
                id INT AUTO_INCREMENT PRIMARY KEY,
                admin_id INT NOT NULL,
                phone_number VARCHAR(50) NOT NULL,
                message TEXT NOT NULL,
                status ENUM('sent', 'failed') DEFAULT 'sent',
                created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
                FOREIGN KEY (admin_id) REFERENCES admins(id) ON DELETE CASCADE
            ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;
        `);
        console.log('Migration Success: withdrawals, admin_subscriptions, and sms_logs tables checked/created.');
    } catch (err) {
        console.error('Migration Error (Withdrawals & Subscriptions):', err);
    }

    try {
        // Migration 13: Ensure vouchers table has is_giveaway and package_ref columns
        const columnExists = async (table, column) => {
            const [rows] = await db.query(`SHOW COLUMNS FROM ${table} LIKE '${column}'`);
            return rows.length > 0;
        };

        if (!(await columnExists('vouchers', 'is_giveaway'))) {
            console.log("Migration: Adding is_giveaway to vouchers...");
            await db.query("ALTER TABLE vouchers ADD COLUMN is_giveaway TINYINT(1) DEFAULT 0");
        }

        if (!(await columnExists('vouchers', 'package_ref'))) {
            console.log("Migration: Adding package_ref to vouchers...");
            await db.query("ALTER TABLE vouchers ADD COLUMN package_ref VARCHAR(255) DEFAULT NULL");
        }

        console.log('Migration Success: Voucher columns checked/created.');
    } catch (err) {
        console.error('Migration Error (Voucher Columns):', err);
    }

    try {
        // Migration 14: Update legacy portal_dns entries from wipay.com to ugpay.tech
        await db.query("UPDATE admins SET portal_dns = REPLACE(portal_dns, '.wipay.com', '.ugpay.tech') WHERE portal_dns LIKE '%.wipay.com'");
        await db.query("UPDATE admins SET portal_dns = REPLACE(portal_dns, 'wipay.com', 'ugpay.tech') WHERE portal_dns = 'wipay.com'");
        console.log('Migration Success: Legacy portal_dns entries updated to .ugpay.tech');
    } catch (err) {
        console.error('Migration Error (portal_dns update):', err);
    }

    try {
        // Migration 15: Fix failed_low_sms transactions and convert them to success
        await db.query("UPDATE transactions SET status = 'success' WHERE status = 'failed_low_sms'");
        console.log('Migration Success: Converted failed_low_sms transactions to success.');
    } catch (err) {
        console.error('Migration Error (Fix failed_low_sms):', err);
    }

    try {
        // Migration 17: Regenerate valid WireGuard keys for any routers with dummy AAAAAA keys
        const { generateWgKeys, rebuildWireGuardConfig } = require('./vpn');
        const [dummyRouters] = await db.query("SELECT id, name FROM routers WHERE wg_private_key LIKE 'AAAAA%' OR wg_private_key LIKE '%AAA==' OR wg_private_key IS NULL");
        if (dummyRouters.length > 0) {
            console.log(`Migration: Regenerating valid WireGuard keys for ${dummyRouters.length} routers...`);
            for (const r of dummyRouters) {
                const { privateKey, publicKey } = generateWgKeys();
                await db.query("UPDATE routers SET wg_private_key = ?, wg_public_key = ? WHERE id = ?", [privateKey, publicKey, r.id]);
            }
            await rebuildWireGuardConfig();
            console.log("Migration Success: WireGuard keys regenerated and synced to wg0.conf.");
        }
    } catch (err) {
        console.error('Migration Error (Fix WireGuard Keys):', err);
    }

    // Migration 16 & 18: Sync all vouchers to RADIUS radcheck
    // Note: Full re-sync is disabled during standard startup because vouchers are already synced upon creation.
    // Re-running this on every startup causes server boot to take minutes for large voucher databases.
    /*
    try {
        const { syncVoucherToRadius } = require('./radius');
        const [allVouchers] = await db.query('SELECT code, package_id FROM vouchers');
        for (const v of allVouchers) {
            await syncVoucherToRadius(v.code, v.package_id);
        }
        console.log(`Migration Success: Synced ${allVouchers.length} vouchers to RADIUS.`);
    } catch (err) {
        console.error('Migration Error (Sync vouchers to RADIUS):', err);
    }
    */
    try {
        // Migration 19: Add RouterOS API credentials to routers table and timestamp tracking to vouchers table
        const columnExists = async (table, column) => {
            const [rows] = await db.query(`SHOW COLUMNS FROM ${table} LIKE '${column}'`);
            return rows.length > 0;
        };

        if (!(await columnExists('routers', 'api_port'))) {
            console.log("Migration: Adding api_port to routers...");
            await db.query("ALTER TABLE routers ADD COLUMN api_port INT DEFAULT 8728");
        }
        if (!(await columnExists('routers', 'api_user'))) {
            console.log("Migration: Adding api_user to routers...");
            await db.query("ALTER TABLE routers ADD COLUMN api_user VARCHAR(100) DEFAULT 'admin'");
        }
        if (!(await columnExists('routers', 'api_password'))) {
            console.log("Migration: Adding api_password to routers...");
            await db.query("ALTER TABLE routers ADD COLUMN api_password VARCHAR(255) DEFAULT NULL");
        }

        if (!(await columnExists('vouchers', 'first_used_at'))) {
            console.log("Migration: Adding first_used_at to vouchers...");
            await db.query("ALTER TABLE vouchers ADD COLUMN first_used_at DATETIME DEFAULT NULL");
        }
        if (!(await columnExists('vouchers', 'expires_at'))) {
            console.log("Migration: Adding expires_at to vouchers...");
            await db.query("ALTER TABLE vouchers ADD COLUMN expires_at DATETIME DEFAULT NULL");
        }

        console.log('Migration Success: Router API credentials and voucher expiration timestamps checked/added.');
    } catch (err) {
        console.error('Migration Error (Router API & Voucher Timestamps):', err);
    }

    try {
        // Migration 20: Ensure all package and voucher columns exist to prevent 500 SQL errors
        const columnExists = async (table, column) => {
            const [rows] = await db.query(`SHOW COLUMNS FROM ${table} LIKE '${column}'`);
            return rows.length > 0;
        };

        // Packages Table Column Checks
        if (!(await columnExists('packages', 'rate_limit'))) {
            console.log("Migration: Adding rate_limit to packages...");
            await db.query("ALTER TABLE packages ADD COLUMN rate_limit VARCHAR(100) DEFAULT '1M/1M'");
        }
        if (!(await columnExists('packages', 'simultaneous_devices'))) {
            console.log("Migration: Adding simultaneous_devices to packages...");
            await db.query("ALTER TABLE packages ADD COLUMN simultaneous_devices INT DEFAULT 1");
        }
        if (!(await columnExists('packages', 'data_limit_mb'))) {
            console.log("Migration: Adding data_limit_mb to packages...");
            await db.query("ALTER TABLE packages ADD COLUMN data_limit_mb INT DEFAULT 0");
        }

        // Vouchers Table Column Checks
        if (!(await columnExists('vouchers', 'used_by'))) {
            console.log("Migration: Adding used_by to vouchers...");
            await db.query("ALTER TABLE vouchers ADD COLUMN used_by VARCHAR(50) DEFAULT NULL");
        }
        if (!(await columnExists('vouchers', 'used_at'))) {
            console.log("Migration: Adding used_at to vouchers...");
            await db.query("ALTER TABLE vouchers ADD COLUMN used_at DATETIME DEFAULT NULL");
        }
        if (!(await columnExists('vouchers', 'comment'))) {
            console.log("Migration: Adding comment to vouchers...");
            await db.query("ALTER TABLE vouchers ADD COLUMN comment VARCHAR(255) DEFAULT NULL");
        }

        console.log('Migration Success: All package and voucher schema columns verified.');
    } catch (err) {
        console.error('Migration Error (Package/Voucher Schema Verification):', err);
    }
}

module.exports = { runPendingMigrations };

