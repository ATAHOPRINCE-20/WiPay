const { RouterOSClient } = require('node-routeros');

/**
 * Creates and connects a RouterOSClient instance with timeout protection.
 */
async function createClient({ host, port = 8728, user = 'admin', password = '' }, timeoutMs = 4000) {
    const client = new RouterOSClient({
        host,
        port: parseInt(port, 10) || 8728,
        user: user || 'admin',
        password: password || '',
        timeout: timeoutMs,
        keepalive: false
    });

    let timeoutHandle;
    const timeoutPromise = new Promise((_, reject) => {
        timeoutHandle = setTimeout(() => {
            reject(new Error(`Connection to MikroTik ${host}:${port} timed out after ${timeoutMs}ms`));
        }, timeoutMs);
    });

    try {
        await Promise.race([client.connect(), timeoutPromise]);
        clearTimeout(timeoutHandle);
        return client;
    } catch (err) {
        clearTimeout(timeoutHandle);
        try { client.close(); } catch (e) {}
        throw err;
    }
}

/**
 * Fetch live active hotspot users directly from MikroTik API
 */
async function fetchLiveActiveHotspotUsers(routerConfig) {
    let client;
    try {
        client = await createClient(routerConfig);
        const activeRows = await client.menu('/ip/hotspot/active').get();
        client.close();

        return activeRows.map(row => ({
            id: row['.id'],
            username: row['user'] || row['name'] || 'Unknown',
            framedipaddress: row['address'] || '',
            callingstationid: row['mac-address'] || '',
            uptime: row['uptime'] || '0s',
            session_time_left: row['session-time-left'] || row['limit-uptime'] || 'N/A',
            idle_time: row['idle-time'] || '0s',
            acctinputoctets: parseInt(row['bytes-in'], 10) || 0,
            acctoutputoctets: parseInt(row['bytes-out'], 10) || 0,
            login_by: row['login-by'] || 'http',
            source: 'mikrotik_api'
        }));
    } catch (err) {
        if (client) { try { client.close(); } catch (e) {} }
        console.warn(`[MikroTik API] Failed to fetch active users from ${routerConfig.host}:`, err.message);
        throw err;
    }
}

/**
 * Fetch connected network devices (DHCP leases & Hotspot hosts) from MikroTik API
 */
async function fetchConnectedDevices(routerConfig) {
    let client;
    try {
        client = await createClient(routerConfig);
        
        const [leases, hosts] = await Promise.all([
            client.menu('/ip/dhcp-server/lease').get().catch(() => []),
            client.menu('/ip/hotspot/host').get().catch(() => [])
        ]);
        client.close();

        const deviceMap = new Map();

        // 1. Process DHCP leases
        for (const l of leases) {
            const mac = (l['mac-address'] || '').toUpperCase();
            if (!mac) continue;
            deviceMap.set(mac, {
                id: l['.id'],
                mac: mac,
                ip: l['active-address'] || l['address'] || '',
                hostname: l['host-name'] || l['comment'] || 'Unknown Device',
                status: l['status'] || 'bound',
                dynamic: l['dynamic'] === 'true',
                source: 'dhcp',
                expires_after: l['expires-after'] || 'N/A'
            });
        }

        // 2. Augment / Add Hotspot hosts
        for (const h of hosts) {
            const mac = (h['mac-address'] || '').toUpperCase();
            if (!mac) continue;
            const existing = deviceMap.get(mac) || {};
            deviceMap.set(mac, {
                id: existing.id || h['.id'],
                mac: mac,
                ip: h['address'] || existing.ip || '',
                hostname: existing.hostname || h['comment'] || 'Hotspot Host',
                status: h['authorized'] === 'true' ? 'authorized' : (h['bypassed'] === 'true' ? 'bypassed' : 'unauthorized'),
                uptime: h['uptime'] || '0s',
                bytes_in: parseInt(h['bytes-in'], 10) || 0,
                bytes_out: parseInt(h['bytes-out'], 10) || 0,
                source: existing.source ? `${existing.source}+hotspot` : 'hotspot'
            });
        }

        return Array.from(deviceMap.values());
    } catch (err) {
        if (client) { try { client.close(); } catch (e) {} }
        console.warn(`[MikroTik API] Failed to fetch connected devices from ${routerConfig.host}:`, err.message);
        throw err;
    }
}

/**
 * Disconnect a user session directly on MikroTik via RouterOS API
 */
async function disconnectHotspotUser(routerConfig, usernameOrId) {
    let client;
    try {
        client = await createClient(routerConfig);
        const activeRows = await client.menu('/ip/hotspot/active').get();
        
        const matching = activeRows.filter(r => 
            r['.id'] === usernameOrId || 
            r['user'] === usernameOrId || 
            (r['user'] && r['user'].toLowerCase() === usernameOrId.toLowerCase()) ||
            r['address'] === usernameOrId ||
            r['mac-address'] === usernameOrId
        );

        let removedCount = 0;
        for (const row of matching) {
            await client.menu('/ip/hotspot/active').remove(row['.id']);
            removedCount++;
        }

        client.close();
        console.log(`[MikroTik API] Removed ${removedCount} active session(s) for ${usernameOrId} on ${routerConfig.host}`);
        return removedCount > 0;
    } catch (err) {
        if (client) { try { client.close(); } catch (e) {} }
        console.error(`[MikroTik API] Error disconnecting user ${usernameOrId} on ${routerConfig.host}:`, err.message);
        return false;
    }
}

module.exports = {
    fetchLiveActiveHotspotUsers,
    fetchConnectedDevices,
    disconnectHotspotUser
};
