const express = require('express');
const router = express.Router();
const db = require('../config/db');
const { authenticateToken } = require('../middleware/auth');
const { sendSMS } = require('../utils/sms');
const { syncVoucherToRadius, syncBatchVouchersToRadius, deleteVoucherFromRadius } = require('../utils/radius');
const multer = require('multer');
const csv = require('csv-parser');
const fs = require('fs');
const path = require('path');

// Configure Multer for temp uploads
const upload = multer({ dest: 'uploads/' });

// Middleware applied to all routes in this file
router.use('/admin', authenticateToken);

// --- Categories ---
router.post('/admin/categories', async (req, res) => {
    const { name, router_id } = req.body;
    if (!name) return res.status(400).json({ error: 'Name is required' });

    try {
        const [result] = await db.query('INSERT INTO categories (name, admin_id, router_id) VALUES (?, ?, ?)', [name, req.user.id, router_id || null]);
        req.io.emit('data_update', { type: 'categories' });
        res.json({ id: result.insertId, name, router_id, message: 'Category created' });
    } catch (err) {
        console.error('Create Category Error:', err);
        res.status(500).json({ error: 'Failed to create category' });
    }
});

router.get('/admin/categories', async (req, res) => {
    try {
        const router_id = req.query.router_id;
        let query = 'SELECT * FROM categories WHERE admin_id = ?';
        let params = [req.user.id];

        if (router_id && router_id !== 'all') {
            query += ' AND router_id = ?'; // STRICT: Show ONLY specific
            params.push(router_id);
        } else {
            // For "All", maybe show everything? Or only Globals?
            // Let's show everything for now.
        }

        query += ' ORDER BY created_at DESC';

        const [rows] = await db.query(query, params);
        res.json(rows);
    } catch (err) {
        res.status(500).json({ error: 'Failed to fetch categories' });
    }
});



router.put('/admin/categories/:id', async (req, res) => {
    const { name } = req.body;
    if (!name) return res.status(400).json({ error: 'Name is required' });

    try {
        const [result] = await db.query('UPDATE categories SET name = ? WHERE id = ? AND admin_id = ?', [name, req.params.id, req.user.id]);
        if (result.affectedRows === 0) return res.status(404).json({ error: 'Category not found' });

        req.io.emit('data_update', { type: 'categories' });
        req.io.emit('data_update', { type: 'packages' }); // Cascaded UI update
        res.json({ message: 'Category updated successfully' });
    } catch (err) {
        console.error('Update Category Error:', err);
        res.status(500).json({ error: 'Failed to update category' });
    }
});

router.delete('/admin/categories/:id', async (req, res) => {
    const categoryId = req.params.id;
    const connection = await db.getConnection();

    try {
        await connection.beginTransaction();

        // 1. Verify Category Ownership
        const [cat] = await connection.query('SELECT id FROM categories WHERE id = ? AND admin_id = ?', [categoryId, req.user.id]);
        if (cat.length === 0) {
            await connection.rollback();
            return res.status(404).json({ error: 'Category not found' });
        }

        // 2. Get Package IDs linked to this category
        const [packages] = await connection.query('SELECT id FROM packages WHERE category_id = ?', [categoryId]);
        const packageIds = packages.map(p => p.id);

        if (packageIds.length > 0) {
            // 3. Delete Vouchers linked to these packages
            const placeholders = packageIds.map(() => '?').join(',');
            await connection.query(`DELETE FROM vouchers WHERE package_id IN (${placeholders})`, packageIds);

            // 4. Delete Packages
            await connection.query('DELETE FROM packages WHERE category_id = ?', [categoryId]);
        }

        // 5. Delete Category
        await connection.query('DELETE FROM categories WHERE id = ?', [categoryId]);

        await connection.commit();
        req.io.emit('data_update', { type: 'categories' });
        req.io.emit('data_update', { type: 'packages' }); // Cascaded
        req.io.emit('data_update', { type: 'vouchers' }); // Cascaded
        res.json({ message: 'Category and all related data deleted successfully' });

    } catch (err) {
        await connection.rollback();
        console.error('Delete Category Error:', err);
        res.status(500).json({ error: 'Failed to delete category' });
    } finally {
        connection.release();
    }
});


const { generateWgKeys, allocateVpnIp, rebuildWireGuardConfig } = require('../utils/vpn');
const { execSync } = require('child_process');

function getVpsWgPublicKey() {
    if (process.env.WG_SERVER_PUBLIC_KEY) return process.env.WG_SERVER_PUBLIC_KEY;
    try {
        return execSync('sudo cat /etc/wireguard/server_public.key', { stdio: ['pipe', 'pipe', 'ignore'] }).toString().trim();
    } catch (e) {
        return 'YOUR_VPS_WG_PUBLIC_KEY';
    }
}

function generateMikrotikScript({ routerName, vpnIp, routerPrivateKey, vpsPublicIp, vpsWgPublicKey, radiusSecret, portalSlug, centralDomain }) {
    const wgPubKey = vpsWgPublicKey || getVpsWgPublicKey();
    return `# ======================================================
# --- WiPay MikroTik Master Setup Script ---
# Router Name: ${routerName}
# VPN IP: ${vpnIp}
# ======================================================

# 1. Create LAN Bridge & Assign IP Address
/interface bridge add name=bridge-lan comment="WiPay LAN Bridge"
/interface bridge port add bridge=bridge-lan interface=ether2 comment="LAN Port 2"
/interface bridge port add bridge=bridge-lan interface=ether3 comment="LAN Port 3"
/interface bridge port add bridge=bridge-lan interface=ether4 comment="LAN Port 4"
/interface bridge port add bridge=bridge-lan interface=ether5 comment="LAN Port 5"
/ip address add address=192.168.88.1/24 interface=bridge-lan comment="WiPay LAN IP"

# 2. Configure WAN (ether1) Internet & NAT
/ip dhcp-client add interface=ether1 disabled=no add-default-route=yes comment="WiPay WAN Client"
/ip firewall nat add chain=srcnat out-interface=ether1 action=masquerade comment="WiPay Internet NAT"

# 3. Enable Wi-Fi Access Point (wlan1)
/interface wireless enable [find default-name=wlan1]
/interface wireless set [find default-name=wlan1] mode=ap-bridge ssid="WiPay Free WiFi" security-profile=default disabled=no
/interface bridge port add bridge=bridge-lan interface=wlan1 comment="Wi-Fi Hotspot Port"

# 4. Create IP Pool & DHCP Server for Hotspot Users
/ip pool add name=hs-pool-1 ranges=192.168.88.10-192.168.88.254
/ip dhcp-server add name=dhcp-hs interface=bridge-lan address-pool=hs-pool-1 disabled=no
/ip dhcp-server network add address=192.168.88.0/24 gateway=192.168.88.1 dns-server=8.8.8.8,1.1.1.1

# 5. Enable Hotspot Server & Hotspot Profile
/ip hotspot profile add name=hsprof-wipay hotspot-address=192.168.88.1 dns-name="wifi.portal" html-directory=hotspot use-radius=yes login-by=http-pap rate-limit="" radius-interim-update=1m
/ip hotspot profile set [find default=yes] hotspot-address=192.168.88.1 login-by=http-pap use-radius=yes radius-interim-update=1m
/ip hotspot add name=hs-wipay interface=bridge-lan address-pool=hs-pool-1 profile=hsprof-wipay disabled=no

# 6. Walled Garden Rules (Allow DNS, Central Portal & Payment Gateways)
/ip hotspot walled-garden ip add action=accept protocol=17 dst-port=53 comment="Allow DNS Queries"
/ip hotspot walled-garden add dst-host="${centralDomain}" action=allow comment="Allow Central Portal HTTP"
/ip hotspot walled-garden ip add dst-host="${centralDomain}" action=accept comment="Allow Central Portal HTTPS"
/ip hotspot walled-garden add dst-host="*.relworx.com" action=allow comment="Allow Payment Gateway HTTP"
/ip hotspot walled-garden ip add dst-host="*.relworx.com" action=accept comment="Allow Payment Gateway HTTPS"
/ip hotspot walled-garden add dst-host="*.googleapis.com" action=allow comment="Allow Google Fonts"
/ip hotspot walled-garden add dst-host="*.gstatic.com" action=allow comment="Allow Google Assets"

# 7. Enable SNTP Client for Time Sync
/system ntp client set enabled=yes primary-ntp=162.159.200.1 secondary-ntp=216.239.35.0

# 8. WireGuard VPN Interface Setup
:do { /interface wireguard peers remove [find interface=wg-wipay] } on-error={}
:do { /ip address remove [find interface=wg-wipay] } on-error={}
:do { /interface wireguard remove [find name=wg-wipay] } on-error={}
/interface wireguard add name=wg-wipay listen-port=51820 private-key="${routerPrivateKey || ''}" comment="WiPay VPN Tunnel"
/ip address add address=${vpnIp}/24 interface=wg-wipay comment="WiPay VPN IP"

# 9. Add VPS as WireGuard Peer
/interface wireguard peers add interface=wg-wipay public-key="${wgPubKey}" endpoint-address=${vpsPublicIp} endpoint-port=51820 allowed-address=10.66.66.1/32 persistent-keepalive=25s comment="WiPay Central Server"

# 10. Add RADIUS Server Configuration
:if ([:len [/radius find service=hotspot]] = 0) do={
  /radius add service=hotspot address=10.66.66.1 secret="${radiusSecret || 'secret123'}" timeout=3s comment="WiPay RADIUS Server"
} else={
  /radius set [find service=hotspot] address=10.66.66.1 secret="${radiusSecret || 'secret123'}" timeout=3s
}
/radius incoming set accept=yes port=3799

# 11. Create & Overwrite Hotspot Redirect login.html with Admin Portal Slug
:if ([:len [/file find name="hotspot/login.html"]] > 0) do={
  /file set "hotspot/login.html" contents="<!DOCTYPE html><html><head><meta charset='utf-8'><meta http-equiv='refresh' content='0; url=http://${centralDomain}/captive-portal?slug=${portalSlug}&link-login=\$(link-login-only)&mac=\$(mac)&ip=\$(ip)&link-orig=\$(link-orig-esc)' /><title>Connecting to WiPay...</title></head><body><div style='font-family: sans-serif; text-align: center; margin-top: 100px; color: #4B5563;'><p style='font-weight: bold;'>Connecting to Wi-Fi Portal...</p><p style='font-size: 14px;'>If you are not redirected automatically, <a href='http://${centralDomain}/captive-portal?slug=${portalSlug}&link-login=\$(link-login-only)&mac=\$(mac)&ip=\$(ip)&link-orig=\$(link-orig-esc)'>click here</a>.</p></div></body></html>"
} else={
  /file add name="hotspot/login.html" contents="<!DOCTYPE html><html><head><meta charset='utf-8'><meta http-equiv='refresh' content='0; url=http://${centralDomain}/captive-portal?slug=${portalSlug}&link-login=\$(link-login-only)&mac=\$(mac)&ip=\$(ip)&link-orig=\$(link-orig-esc)' /><title>Connecting to WiPay...</title></head><body><div style='font-family: sans-serif; text-align: center; margin-top: 100px; color: #4B5563;'><p style='font-weight: bold;'>Connecting to Wi-Fi Portal...</p><p style='font-size: 14px;'>If you are not redirected automatically, <a href='http://${centralDomain}/captive-portal?slug=${portalSlug}&link-login=\$(link-login-only)&mac=\$(mac)&ip=\$(ip)&link-orig=\$(link-orig-esc)'>click here</a>.</p></div></body></html>"
}
`;
}

// --- Routers ---
const { fetchLiveActiveHotspotUsers, fetchConnectedDevices, disconnectHotspotUser } = require('../utils/mikrotikApi');

router.post('/admin/routers', async (req, res) => {
    const { name, ip_address, secret, api_port, api_user, api_password } = req.body;
    if (!name || !secret) {
        return res.status(400).json({ error: 'Router Name and RADIUS Secret are required' });
    }

    try {
        // 1. Allocate IP if not provided
        let finalIp = ip_address ? ip_address.trim() : null;
        if (!finalIp) {
            finalIp = await allocateVpnIp();
        }

        // 2. Generate WireGuard keys
        const { privateKey, publicKey } = generateWgKeys();

        // 3. Insert into routers table
        const [result] = await db.query(
            'INSERT INTO routers (name, ip_address, radius_secret, wg_private_key, wg_public_key, admin_id, api_port, api_user, api_password) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)',
            [name, finalIp, secret, privateKey, publicKey, req.user.id, parseInt(api_port, 10) || 8728, api_user || 'admin', api_password || null]
        );
        const routerId = result.insertId;

        // 4. Insert or update in FreeRADIUS nas table
        try {
            await db.query(
                `INSERT INTO nas (nasname, shortname, type, secret, description) 
                 VALUES (?, ?, 'mikrotik', ?, ?) 
                 ON DUPLICATE KEY UPDATE secret = VALUES(secret), shortname = VALUES(shortname)`,
                [finalIp, name, secret, `Router ID ${routerId}`]
            );
        } catch (nasErr) {
            console.warn('[ROUTER] Could not update NAS table:', nasErr.message);
        }

        // 5. Rebuild WireGuard config on VPS
        await rebuildWireGuardConfig();

        // 6. Fetch Admin Portal Slug & VPS Domain
        let portalSlug = 'default';
        try {
            const [adminRows] = await db.query('SELECT portal_slug FROM admins WHERE id = ?', [req.user.id]);
            if (adminRows.length > 0 && adminRows[0].portal_slug) {
                portalSlug = adminRows[0].portal_slug;
            }
        } catch (e) {}

        const vpsIp = process.env.VPS_PUBLIC_IP || process.env.DOMAIN || '84.46.253.72';
        const vpsWgPublicKey = process.env.WG_SERVER_PUBLIC_KEY || getVpsWgPublicKey();

        // 7. Build MikroTik Setup Script
        const script = generateMikrotikScript({
            routerName: name,
            vpnIp: finalIp,
            routerPrivateKey: privateKey,
            vpsPublicIp: vpsIp,
            vpsWgPublicKey: vpsWgPublicKey,
            radiusSecret: secret,
            portalSlug: portalSlug,
            centralDomain: process.env.CENTRAL_DOMAIN || 'wifi.ugpay.tech'
        });

        req.io.emit('data_update', { type: 'routers' });
        res.json({ id: routerId, name, ip_address: finalIp, script, message: 'Router added successfully' });

    } catch (err) {
        console.error('Create Router Error:', err);
        res.status(500).json({ error: 'Failed to add router: ' + err.message });
    }
});

router.get('/admin/routers/stats', async (req, res) => {
    try {
        const adminId = req.user.id;
        const [routers] = await db.query(`
            SELECT 
                r.*,
                COALESCE(t.total_revenue, 0) as total_revenue,
                COALESCE(t.daily_revenue, 0) as daily_revenue,
                COALESCE(v.voucher_stock, 0) as voucher_stock
            FROM routers r
            LEFT JOIN (
                SELECT 
                    router_id,
                    SUM(amount) as total_revenue,
                    SUM(CASE WHEN DATE(created_at) = CURDATE() THEN amount ELSE 0 END) as daily_revenue
                FROM transactions
                WHERE status = 'success'
                GROUP BY router_id
            ) t ON r.id = t.router_id
            LEFT JOIN (
                SELECT p.router_id, COUNT(v.id) as voucher_stock
                FROM vouchers v
                JOIN packages p ON v.package_id = p.id
                WHERE (v.is_used = 0 OR v.is_used IS NULL)
                GROUP BY p.router_id
            ) v ON r.id = v.router_id
            WHERE r.admin_id = ?
            ORDER BY r.created_at DESC
        `, [adminId]);

        res.json(routers);
    } catch (err) {
        console.error('Fetch Routers Stats Error:', err);
        res.status(500).json({ error: 'Failed to fetch router stats' });
    }
});

router.get('/admin/routers', async (req, res) => {
    try {
        const [rows] = await db.query(`
            SELECT r.*,
                   (SELECT COUNT(*) 
                    FROM radacct a 
                    WHERE a.acctstoptime IS NULL 
                      AND (a.nasipaddress = r.ip_address OR a.nasipaddress = r.wg_ip OR (SELECT COUNT(*) FROM routers WHERE admin_id = ?) = 1)
                   ) as active_sessions_count
            FROM routers r 
            WHERE r.admin_id = ? 
            ORDER BY r.created_at DESC
        `, [req.user.id, req.user.id]);
        res.json(rows);
    } catch (err) {
        console.error('Fetch Routers Error:', err);
        res.status(500).json({ error: 'Failed to fetch routers' });
    }
});

router.get('/admin/routers/sessions', async (req, res) => {
    try {
        const [rows] = await db.query(`
            SELECT a.username, a.nasipaddress, a.framedipaddress, a.callingstationid, 
                   a.acctinputoctets, a.acctoutputoctets, a.acctstarttime,
                   COALESCE(r.name, 'MILE 2') as router_name
            FROM radacct a
            LEFT JOIN routers r ON (a.nasipaddress = r.ip_address OR a.nasipaddress = r.wg_ip)
            WHERE a.acctstoptime IS NULL 
            ORDER BY a.acctstarttime DESC 
            LIMIT 200
        `);
        res.json(rows);
    } catch (err) {
        console.error('Fetch Sessions Error:', err);
        res.json([]);
    }
});

router.get('/admin/routers/:id/script', async (req, res) => {
    try {
        const [rows] = await db.query('SELECT * FROM routers WHERE id = ? AND admin_id = ?', [req.params.id, req.user.id]);
        if (rows.length === 0) return res.status(404).json({ error: 'Router not found' });

        const routerItem = rows[0];
        let portalSlug = 'default';
        try {
            const [adminRows] = await db.query('SELECT portal_slug FROM admins WHERE id = ?', [req.user.id]);
            if (adminRows.length > 0 && adminRows[0].portal_slug) {
                portalSlug = adminRows[0].portal_slug;
            }
        } catch (e) {}

        const vpsIp = process.env.VPS_PUBLIC_IP || process.env.DOMAIN || '84.46.253.72';
        const vpsWgPublicKey = process.env.WG_SERVER_PUBLIC_KEY || getVpsWgPublicKey();

        const script = generateMikrotikScript({
            routerName: routerItem.name,
            vpnIp: routerItem.ip_address,
            routerPrivateKey: routerItem.wg_private_key,
            vpsPublicIp: vpsIp,
            vpsWgPublicKey: vpsWgPublicKey,
            radiusSecret: routerItem.radius_secret,
            portalSlug: portalSlug,
            centralDomain: process.env.CENTRAL_DOMAIN || 'wifi.ugpay.tech'
        });

        res.json({ script });
    } catch (err) {
        console.error('Fetch Router Script Error:', err);
        res.status(500).json({ error: 'Failed to generate router script' });
    }
});

router.get('/admin/routers/:id/live-active', async (req, res) => {
    try {
        const [routers] = await db.query('SELECT * FROM routers WHERE id = ? AND admin_id = ?', [req.params.id, req.user.id]);
        if (routers.length === 0) return res.status(404).json({ error: 'Router not found' });

        const r = routers[0];
        try {
            const liveUsers = await fetchLiveActiveHotspotUsers({
                host: r.ip_address,
                port: r.api_port || 8728,
                user: r.api_user || 'admin',
                password: r.api_password || ''
            });
            return res.json({ source: 'mikrotik_api', router_name: r.name, users: liveUsers });
        } catch (apiErr) {
            console.warn(`[Live Active] MikroTik API unreachable for router ${r.id} (${r.ip_address}):`, apiErr.message);
            
            // Fallback to radacct table
            const [rows] = await db.query(`
                SELECT a.username, a.nasipaddress, a.framedipaddress, a.callingstationid, 
                       a.acctinputoctets, a.acctoutputoctets, a.acctstarttime,
                       '0s' as uptime, 'N/A' as session_time_left, 'radius_db' as source
                FROM radacct a
                WHERE a.acctstoptime IS NULL 
                  AND (a.nasipaddress = ? OR a.nasipaddress = ?)
                ORDER BY a.acctstarttime DESC 
            `, [r.ip_address, r.wg_ip || r.ip_address]);

            return res.json({ source: 'radius_db', router_name: r.name, users: rows, warning: 'MikroTik API unreachable. Showing RADIUS fallback.' });
        }
    } catch (err) {
        console.error('Fetch Live Active Users Error:', err);
        res.status(500).json({ error: 'Failed to fetch active users' });
    }
});

router.get('/admin/routers/:id/live-devices', async (req, res) => {
    try {
        const [routers] = await db.query('SELECT * FROM routers WHERE id = ? AND admin_id = ?', [req.params.id, req.user.id]);
        if (routers.length === 0) return res.status(404).json({ error: 'Router not found' });

        const r = routers[0];
        try {
            const devices = await fetchConnectedDevices({
                host: r.ip_address,
                port: r.api_port || 8728,
                user: r.api_user || 'admin',
                password: r.api_password || ''
            });
            return res.json({ source: 'mikrotik_api', router_name: r.name, devices });
        } catch (apiErr) {
            console.warn(`[Live Devices] MikroTik API unreachable for router ${r.id} (${r.ip_address}):`, apiErr.message);

            // Fallback to unique MAC addresses in radacct
            const [rows] = await db.query(`
                SELECT DISTINCT callingstationid as mac, framedipaddress as ip, username as hostname, 
                       'radius_db' as source, 'bound' as status
                FROM radacct 
                WHERE (nasipaddress = ? OR nasipaddress = ?) AND callingstationid IS NOT NULL AND callingstationid != ''
                ORDER BY acctstarttime DESC LIMIT 100
            `, [r.ip_address, r.wg_ip || r.ip_address]);

            return res.json({ source: 'radius_db', router_name: r.name, devices: rows, warning: 'MikroTik API unreachable. Showing RADIUS fallback.' });
        }
    } catch (err) {
        console.error('Fetch Live Devices Error:', err);
        res.status(500).json({ error: 'Failed to fetch connected devices' });
    }
});

router.post('/admin/routers/:id/disconnect-user', async (req, res) => {
    const { username } = req.body;
    if (!username) return res.status(400).json({ error: 'Username is required' });

    try {
        const [routers] = await db.query('SELECT * FROM routers WHERE id = ? AND admin_id = ?', [req.params.id, req.user.id]);
        if (routers.length === 0) return res.status(404).json({ error: 'Router not found' });

        const r = routers[0];
        const { disconnectVoucherSession } = require('../utils/radius');

        // 1. Try API disconnect
        const apiSuccess = await disconnectHotspotUser({
            host: r.ip_address,
            port: r.api_port || 8728,
            user: r.api_user || 'admin',
            password: r.api_password || ''
        }, username).catch(() => false);

        // 2. Try RADIUS CoA disconnect
        const radiusSuccess = await disconnectVoucherSession(username).catch(() => false);

        if (apiSuccess || radiusSuccess) {
            req.io.emit('data_update', { type: 'sessions' });
            res.json({ success: true, message: `Disconnected ${username} successfully.` });
        } else {
            res.status(400).json({ error: `Could not disconnect ${username}. Session may already be closed.` });
        }
    } catch (err) {
        console.error('Disconnect User Error:', err);
        res.status(500).json({ error: 'Failed to disconnect user' });
    }
});

router.put('/admin/routers/:id', async (req, res) => {
    const { name, ip_address, secret, wg_public_key, api_port, api_user, api_password } = req.body;
    try {
        let updateQuery = 'UPDATE routers SET name = ?';
        let params = [name];
        if (ip_address) {
            updateQuery += ', ip_address = ?';
            params.push(ip_address);
        }
        if (secret) {
            updateQuery += ', radius_secret = ?';
            params.push(secret);
        }
        if (wg_public_key) {
            updateQuery += ', wg_public_key = ?';
            params.push(wg_public_key);
        }
        if (api_port !== undefined) {
            updateQuery += ', api_port = ?';
            params.push(parseInt(api_port, 10) || 8728);
        }
        if (api_user !== undefined) {
            updateQuery += ', api_user = ?';
            params.push(api_user || 'admin');
        }
        if (api_password !== undefined) {
            updateQuery += ', api_password = ?';
            params.push(api_password);
        }
        updateQuery += ' WHERE id = ? AND admin_id = ?';
        params.push(req.params.id, req.user.id);

        await db.query(updateQuery, params);

        if (ip_address && secret) {
            try {
                await db.query(
                    `INSERT INTO nas (nasname, shortname, type, secret, description) 
                     VALUES (?, ?, 'mikrotik', ?, ?) 
                     ON DUPLICATE KEY UPDATE secret = VALUES(secret), shortname = VALUES(shortname)`,
                    [ip_address, name, secret, `Router ID ${req.params.id}`]
                );
            } catch (e) {}
        }

        // Rebuild WireGuard configuration on VPS to keep VPN in sync
        await rebuildWireGuardConfig();

        req.io.emit('data_update', { type: 'routers' });
        res.json({ message: 'Router updated successfully' });
    } catch (err) {
        console.error('Update Router Error:', err);
        res.status(500).json({ error: 'Failed to update router' });
    }
});

router.delete('/admin/routers/:id', async (req, res) => {
    try {
        await db.query('DELETE FROM routers WHERE id = ? AND admin_id = ?', [req.params.id, req.user.id]);
        await rebuildWireGuardConfig();
        req.io.emit('data_update', { type: 'routers' });
        res.json({ message: 'Router deleted' });
    } catch (err) {
        res.status(500).json({ error: 'Failed to delete router' });
    }
});

// --- Packages ---
router.post('/admin/packages', async (req, res) => {
    const { name, price, validity_hours, validity_minutes, validity_unit, category_id, data_limit_mb, router_id, rate_limit, simultaneous_devices } = req.body;

    if (!name || !price || !category_id) {
        return res.status(400).json({ error: 'Missing required fields' });
    }

    try {
        const unit = (validity_unit === 'minutes' || validity_unit === 'mins') ? 'minutes' : 'hours';
        const vHours = unit === 'hours' ? (parseFloat(validity_hours) || 0) : ((parseFloat(validity_minutes) || 0) / 60);
        const vMins = unit === 'minutes' ? (parseInt(validity_minutes, 10) || 0) : Math.round((parseFloat(validity_hours) || 0) * 60);

        await db.query(`
            INSERT INTO packages (category_id, name, price, validity_hours, validity_minutes, validity_unit, data_limit_mb, rate_limit, simultaneous_devices, created_at, admin_id, router_id)
            VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, NOW(), ?, ?)
        `, [category_id, name, price, vHours, vMins, unit, data_limit_mb || 0, rate_limit || '1M/1M', simultaneous_devices || 1, req.user.id, router_id || null]);
        req.io.emit('data_update', { type: 'packages' });
        res.json({ message: 'Package created successfully' });
    } catch (err) {
        console.error('Create Package Error:', err);
        res.status(500).json({ error: 'Failed to create package' });
    }
});

router.patch('/admin/packages/:id/toggle', async (req, res) => {
    try {
        const [rows] = await db.query('SELECT is_active FROM packages WHERE id = ? AND admin_id = ?', [req.params.id, req.user.id]);
        if (rows.length === 0) return res.status(404).json({ error: 'Package not found' });

        const currentState = rows[0].is_active;
        const newState = !currentState;

        await db.query('UPDATE packages SET is_active = ? WHERE id = ?', [newState, req.params.id]);
        req.io.emit('data_update', { type: 'packages' });
        res.json({ message: 'Package status updated', is_active: newState });
    } catch (err) {
        console.error('Toggle Package Error:', err);
        res.status(500).json({ error: 'Failed to update package status' });
    }
});

router.get('/admin/packages', async (req, res) => {
    try {
        const router_id = req.query.router_id;
        let query = `
            SELECT p.id, p.name, p.price, p.validity_hours, p.validity_minutes, p.validity_unit, p.data_limit_mb, p.rate_limit, p.simultaneous_devices, p.is_active, p.created_at, c.name as category_name, p.router_id,
                   (SELECT COUNT(*) FROM vouchers v WHERE v.package_id = p.id AND (v.is_used = 0 OR v.is_used IS NULL)) as vouchers_count
            FROM packages p 
            LEFT JOIN categories c ON p.category_id = c.id 
            WHERE p.admin_id = ?
        `;
        let params = [req.user.id];

        if (router_id && router_id !== 'all') {
            query += ' AND p.router_id = ?';
            params.push(router_id);
        }

        query += ' ORDER BY p.created_at DESC';

        const [rows] = await db.query(query, params);
        res.json(rows);
    } catch (err) {
        console.error('Fetch Packages Error:', err);
        res.status(500).json({ error: 'Failed to fetch packages' });
    }
});

router.put('/admin/packages/:id', async (req, res) => {
    const { name, price, validity_hours, validity_minutes, validity_unit, data_limit_mb, category_id, rate_limit, simultaneous_devices } = req.body;

    if (!name || !price || !category_id) {
        return res.status(400).json({ error: 'Missing required fields' });
    }

    try {
        const unit = (validity_unit === 'minutes' || validity_unit === 'mins') ? 'minutes' : 'hours';
        const vHours = unit === 'hours' ? (parseFloat(validity_hours) || 0) : ((parseFloat(validity_minutes) || 0) / 60);
        const vMins = unit === 'minutes' ? (parseInt(validity_minutes, 10) || 0) : Math.round((parseFloat(validity_hours) || 0) * 60);

        const [result] = await db.query(`
            UPDATE packages 
            SET name = ?, price = ?, validity_hours = ?, validity_minutes = ?, validity_unit = ?, data_limit_mb = ?, category_id = ?, rate_limit = ?, simultaneous_devices = ?
            WHERE id = ? AND admin_id = ?
        `, [name, price, vHours, vMins, unit, data_limit_mb || 0, category_id, rate_limit || '1M/1M', simultaneous_devices || 1, req.params.id, req.user.id]);

        if (result.affectedRows === 0) return res.status(404).json({ error: 'Package not found' });

        req.io.emit('data_update', { type: 'packages' });
        res.json({ message: 'Package updated successfully' });
    } catch (err) {
        console.error('Update Package Error:', err);
        res.status(500).json({ error: 'Failed to update package' });
    }
});

// --- Vouchers ---
router.post('/admin/vouchers/import', upload.single('file'), async (req, res) => {
    const { package_id, router_id } = req.body; // router_id might come from frontend if package is global

    if (!req.file || !package_id) {
        return res.status(400).json({ error: 'File and package_id are required' });
    }

    const results = [];
    const BATCH_SIZE = 500;
    let totalInserted = 0;

    // Check if package has a router_id
    // If YES, vouchers inherit it. If NO, vouchers might use the passed router_id (if we allow Global Packages to have Specific Vouchers? Complicated. 
    // Simplified Logic: Vouchers inherit Package's router_id. If package is Global, Vouchers are Global. 
    // OR: Vouchers created under specific router view get that router_id.
    // Let's lookup package first.
    let packageRouterId = null;
    try {
        const [pkgRows] = await db.query('SELECT router_id FROM packages WHERE id = ?', [package_id]);
        if (pkgRows.length > 0) packageRouterId = pkgRows[0].router_id;
    } catch (e) { console.error("Error looking up package router:", e); }

    // Final Router ID for vouchers: Package's ID takes precedence (strict), or fallback to passed ID?
    // If Package is Specific, vouchers MUST be specific to that router.
    // If Package is Global (NULL), vouchers CAN be specific (if sold from specific router view) or Global.
    // Use packageRouterId if exists, otherwise use req.body.router_id
    const finalRouterId = packageRouterId || router_id || null;

    const processBatch = async (batch) => {
        if (batch.length === 0) return;

        // Adaptive placeholder: code, comment, package_ref
        const strictValues = [];
        batch.forEach(row => {
            const code = row.code || (Object.values(row)[0]); // First column as code
            const comment = row.comment || null;
            const pkgRef = row.package_ref || null;
            strictValues.push(package_id, code, comment, pkgRef, req.user.id, finalRouterId);
        });

        // We added router_id to the insert columns
        const strictPlaceholder = batch.map(() => '(?, ?, ?, ?, ?, ?)').join(', ');

        const [result] = await db.query(`INSERT IGNORE INTO vouchers (package_id, code, comment, package_ref, admin_id, router_id) VALUES ${strictPlaceholder}`, strictValues);
        totalInserted += result.affectedRows;
    };

    try {
        const stream = fs.createReadStream(req.file.path)
            .pipe(csv())
            .on('data', (data) => {
                results.push(data);
                if (results.length >= BATCH_SIZE) {
                    stream.pause(); // Pause reading while writing to DB
                    const batch = results.splice(0, BATCH_SIZE);
                    processBatch(batch)
                        .then(() => stream.resume())
                        .catch(err => {
                            console.error('Batch Insert Error:', err);
                            stream.destroy(err);
                        });
                }
            })
            .on('end', async () => {
                // Process remaining
                if (results.length > 0) {
                    await processBatch(results);
                }
                // Cleanup file
                fs.unlink(req.file.path, (err) => { if (err) console.error('Cleanup Error:', err); });
                req.io.emit('data_update', { type: 'vouchers' });
                res.json({ message: `Import complete. Processed ${totalInserted} vouchers.` });
            })
            .on('error', (err) => {
                console.error('CSV Stream Error:', err);
                res.status(500).json({ error: 'Failed to process CSV file' });
            });

    } catch (err) {
        console.error('Import Setup Error:', err);
        res.status(500).json({ error: 'Server error during import setup' });
    }
});

function generateVoucherCode(length, prefix) {
    const chars = '23456789ABCDEFGHJKLMNPQRSTUVWXYZ'; // Exclude visually similar chars (0, O, 1, I)
    let code = '';
    for (let i = 0; i < length; i++) {
        code += chars.charAt(Math.floor(Math.random() * chars.length));
    }
    return (prefix || '') + code;
}

router.post('/admin/vouchers/generate', async (req, res) => {
    const { package_id, quantity, prefix, code_length, is_giveaway, batch_ref } = req.body;
    
    if (!package_id || !quantity || quantity <= 0 || quantity > 500) {
        return res.status(400).json({ error: 'Valid package ID and quantity (max 500) are required' });
    }

    try {
        const [pkg] = await db.query('SELECT id, router_id FROM packages WHERE id = ? AND admin_id = ?', [package_id, req.user.id]);
        if (pkg.length === 0) return res.status(404).json({ error: 'Package not found' });

        const router_id = pkg[0].router_id;
        const insertValues = [];
        const generateLength = parseInt(code_length) || 8;

        for (let i = 0; i < quantity; i++) {
            const code = generateVoucherCode(generateLength, prefix);
            insertValues.push([code, package_id, req.user.id, router_id, is_giveaway ? 1 : 0, batch_ref || null]);
        }

        // Batch insert
        await db.query(
            'INSERT INTO vouchers (code, package_id, admin_id, router_id, is_giveaway, package_ref) VALUES ?',
            [insertValues]
        );

        // Background RADIUS sync
        const syncList = insertValues.map(v => ({ code: v[0], packageId: package_id }));
        syncBatchVouchersToRadius(syncList).catch(err => console.error('[RADIUS] Batch sync error:', err));

        req.io.emit('data_update', { type: 'vouchers' });
        res.json({ message: `Successfully generated ${quantity} vouchers.` });
    } catch (err) {
        console.error('Generate Vouchers Error:', err);
        res.status(500).json({ error: 'Failed to generate vouchers: ' + err.message });
    }
});

router.get('/admin/vouchers/export', async (req, res) => {
    const { package_id } = req.query;
    if (!package_id) {
        return res.status(400).json({ error: 'Package ID is required' });
    }

    try {
        const [rows] = await db.query(`
            SELECT v.code, p.name as package_name, p.price, v.is_used, v.used_by, v.used_at, v.created_at, v.package_ref, v.is_giveaway
            FROM vouchers v
            JOIN packages p ON v.package_id = p.id
            WHERE v.package_id = ? AND v.admin_id = ?
            ORDER BY v.created_at DESC
        `, [package_id, req.user.id]);

        let csv = 'Code,Package,Price,Status,Used By,Used At,Created At,Batch Ref,Giveaway\n';
        rows.forEach(r => {
            const status = r.is_used ? 'Used' : 'Available';
            const usedAt = r.used_at ? new Date(r.used_at).toISOString() : '';
            const createdAt = r.created_at ? new Date(r.created_at).toISOString() : '';
            csv += `"${r.code}","${r.package_name}",${r.price},"${status}","${r.used_by || ''}","${usedAt}","${createdAt}","${r.package_ref || ''}","${r.is_giveaway ? 'Yes' : 'No'}"\n`;
        });

        res.setHeader('Content-Type', 'text/csv');
        res.setHeader('Content-Disposition', `attachment; filename=vouchers-pkg-${package_id}.csv`);
        res.send(csv);
    } catch (err) {
        console.error('Export Vouchers Error:', err);
        res.status(500).json({ error: 'Failed to export vouchers: ' + err.message });
    }
});

router.post('/admin/vouchers/bulk-delete', async (req, res) => {
    const { package_id } = req.body;
    if (!package_id) {
        return res.status(400).json({ error: 'Package ID is required' });
    }

    try {
        const [vouchers] = await db.query('SELECT code FROM vouchers WHERE package_id = ? AND is_used = FALSE AND admin_id = ?', [package_id, req.user.id]);
        const [result] = await db.query('DELETE FROM vouchers WHERE package_id = ? AND is_used = FALSE AND admin_id = ?', [package_id, req.user.id]);

        for (const v of vouchers) {
            deleteVoucherFromRadius(v.code).catch(err => console.error('[RADIUS] Deletion error:', err));
        }

        req.io.emit('data_update', { type: 'vouchers' });
        res.json({ message: `Bulk deleted ${result.affectedRows} unused vouchers` });
    } catch (err) {
        console.error('Bulk Delete Vouchers Error:', err);
        res.status(500).json({ error: 'Failed to bulk delete vouchers: ' + err.message });
    }
});

router.get('/admin/vouchers', async (req, res) => {
    try {
        const { router_id, package_id, is_used } = req.query;

        let query = `
            SELECT v.id, v.code, v.comment, v.package_ref, v.is_used, v.is_giveaway, v.used_by, v.used_at, v.created_at, v.router_id,
                   p.id as pkg_id, p.name as package_name, p.price as package_price
            FROM vouchers v
            JOIN packages p ON v.package_id = p.id
            WHERE v.admin_id = ?
        `;
        let params = [req.user.id];

        if (is_used !== undefined && is_used !== '') {
            query += ' AND v.is_used = ?';
            params.push(is_used === '1' || is_used === 'true' ? 1 : 0);
        } else {
            query += ' AND v.is_used = FALSE';
        }

        if (package_id) {
            query += ' AND v.package_id = ?';
            params.push(package_id);
        }

        if (router_id && router_id !== 'all') {
            query += ' AND v.router_id = ?';
            params.push(router_id);
        }

        query += ' ORDER BY v.created_at DESC LIMIT 500';

        const [rows] = await db.query(query, params);
        
        const formatted = rows.map(r => ({
            ...r,
            package: { id: r.pkg_id, name: r.package_name, price: r.package_price }
        }));

        res.json(formatted);
    } catch (err) {
        console.error('Fetch Vouchers Error:', err);
        res.status(500).json({ error: 'Failed to fetch vouchers.' });
    }
});


const RELWORX_API_URL = 'https://payments.relworx.com/api/mobile-money/request-payment';
const RELWORX_API_KEY = process.env.RELWORX_API_KEY;
const RELWORX_ACCOUNT_NO = process.env.RELWORX_ACCOUNT_NO;

router.get('/admin/sms-balance', async (req, res) => {
    try {
        // Calculate balance: Sum of SUCCESS deposits - Sum of usage
        // Note: Usage rows (type='usage') are naturally negative in amount, so straight SUM works 
        // IF we filter properly. Usage doesn't have a status usually, or defaults to success.
        // Let's assume usage is always valid. Deposits must be 'success'.
        const [rows] = await db.query(`
            SELECT SUM(amount) as balance 
            FROM sms_fees 
            WHERE admin_id = ? 
            AND (status = 'success' OR status IS NULL)
            AND type != 'subscription'
        `, [req.user.id]);

        const balance = rows[0].balance || 0;
        res.json({ balance: Math.max(0, Number(balance)) });
    } catch (err) {
        console.error('Fetch SMS Balance Error:', err);
        res.status(500).json({ error: 'Failed to fetch balance' });
    }
});

router.post('/admin/buy-sms', async (req, res) => {
    const { amount, phone_number } = req.body;
    if (!amount || amount <= 0) return res.status(400).json({ error: 'Valid amount is required' });
    if (!phone_number) return res.status(400).json({ error: 'Phone number is required' });

    try {
        // Format Phone (Robust)
        let formattedPhone = phone_number.replace(/\s+/g, ''); // Remove spaces
        if (formattedPhone.startsWith('256')) formattedPhone = '+' + formattedPhone;
        else if (formattedPhone.startsWith('0')) formattedPhone = '+256' + formattedPhone.slice(1);
        else if (!formattedPhone.startsWith('+')) formattedPhone = '+256' + formattedPhone; // Assume local if completely raw

        // Limit Check (Uganda numbers are usually 13 chars: +256 7XX XXX XXX)
        if (formattedPhone.length < 10) return res.status(400).json({ error: 'Invalid phone number length' });

        const reference = `SMS-${Date.now()}-${Math.floor(Math.random() * 1000)}`;

        // 1. Insert Pending Record
        await db.query('INSERT INTO sms_fees (admin_id, amount, type, description, status, reference) VALUES (?, ?, ?, ?, ?, ?)',
            [req.user.id, amount, 'deposit', `Pending Top up via ${formattedPhone}`, 'pending', reference]);

        // 2. Call Relworx
        const response = await fetch(RELWORX_API_URL, {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json',
                'Accept': 'application/vnd.relworx.v2',
                'Authorization': `Bearer ${RELWORX_API_KEY}`
            },
            body: JSON.stringify({
                account_no: RELWORX_ACCOUNT_NO,
                reference: reference,
                msisdn: formattedPhone,
                currency: 'UGX',
                amount: Number(amount),
                description: `SMS Topup`
            })
        });

        const paymentData = await response.json();

        if (response.ok) {
            res.json({
                message: 'Payment request initiated. Please check your phone.',
                status: 'pending',
                reference: reference
            });
        } else {
            console.error(`[SMS-TOPUP-ERROR] Gateway Failed:`, paymentData);
            await db.query('UPDATE sms_fees SET status = "failed" WHERE reference = ?', [reference]);

            // Pass the exact message from Relworx to the frontend
            const errorMsg = paymentData.message || paymentData.description || 'Unknown gateway error';
            res.status(400).json({ error: errorMsg, details: paymentData });
        }
    } catch (err) {
        console.error('Buy SMS Error:', err);
        res.status(500).json({ error: 'Failed to process purchase: ' + err.message });
    }
});

router.get('/admin/sms-status/:reference', async (req, res) => {
    try {
        const [rows] = await db.query('SELECT status, amount FROM sms_fees WHERE reference = ? AND admin_id = ?', [req.params.reference, req.user.id]);
        if (rows.length === 0) return res.status(404).json({ error: 'Transaction not found' });

        const localStatus = rows[0].status;

        // If success or failed, return immediately
        if (localStatus === 'success' || localStatus === 'failed') {
            return res.json({ status: localStatus });
        }

        // --- Active Backup Poll (For Localhost/Backup) ---
        const checkUrl = `https://payments.relworx.com/api/mobile-money/check-request-status?account_no=${RELWORX_ACCOUNT_NO}&reference=${req.params.reference}&internal_reference=${req.params.reference}`;

        try {
            const gwRes = await fetch(checkUrl, {
                method: 'GET',
                headers: {
                    'Accept': 'application/vnd.relworx.v2',
                    'Authorization': `Bearer ${RELWORX_API_KEY}`
                }
            });

            if (!gwRes.ok) return res.json({ status: 'pending' }); // Keep waiting

            const gwData = await gwRes.json();
            const gwStatus = (gwData.status || '').toUpperCase();
            const itemStatus = (gwData.item_status || '').toUpperCase();

            // Check Success
            if (gwStatus === 'SUCCESS' || itemStatus === 'SUCCESS') {
                await db.query('UPDATE sms_fees SET status = "success" WHERE reference = ?', [req.params.reference]);
                return res.json({ status: 'success' });
            }
            // Check Failure
            else if (gwStatus === 'FAILED' || itemStatus === 'FAILED') {
                await db.query('UPDATE sms_fees SET status = "failed" WHERE reference = ?', [req.params.reference]);
                return res.json({ status: 'failed' });
            }

            return res.json({ status: 'pending' });

        } catch (fetchErr) {
            console.error('[SMS-POLL] Fetch Error:', fetchErr);
            return res.json({ status: 'pending' });
        }

    } catch (err) {
        console.error('Check SMS Status Error:', err);
        res.status(500).json({ error: 'Server error' });
    }
});

router.post('/admin/sell-voucher', async (req, res) => {
    const { package_id, phone_number } = req.body;
    const SMS_COST = 35;

    if (!package_id || !phone_number) {
        return res.status(400).json({ error: 'Package and Phone number required' });
    }

    const connection = await db.getConnection(); // Use transaction

    try {
        await connection.beginTransaction();

        // 0. Check SMS Balance
        const [balRows] = await connection.query('SELECT SUM(amount) as balance FROM sms_fees WHERE admin_id = ?', [req.user.id]);
        const balance = Number(balRows[0].balance || 0);

        if (balance < SMS_COST) {
            await connection.rollback();
            return res.status(400).json({ error: `Insufficient SMS balance. Cost: ${SMS_COST}, Balance: ${balance}` });
        }

        // 1. Get Package details
        const [packages] = await connection.query('SELECT * FROM packages WHERE id = ?', [package_id]);
        if (packages.length === 0) {
            await connection.rollback();
            return res.status(404).json({ error: 'Package not found' });
        }
        const pkg = packages[0];

        // 2. Get Available Voucher
        const [vouchers] = await connection.query('SELECT * FROM vouchers WHERE package_id = ? AND is_used = FALSE AND admin_id = ? LIMIT 1 FOR UPDATE', [package_id, req.user.id]);
        if (vouchers.length === 0) {
            await connection.rollback();
            return res.status(400).json({ error: 'No vouchers available for this package' });
        }
        const voucher = vouchers[0];

        // 3. Mark Voucher Used
        await connection.query('UPDATE vouchers SET is_used = 1, used_by = ?, used_at = NOW() WHERE id = ?', [phone_number, voucher.id]);

        // 4. Deduct SMS Cost
        await connection.query('INSERT INTO sms_fees (admin_id, amount, type, description) VALUES (?, ?, ?, ?)',
            [req.user.id, -SMS_COST, 'usage', `Voucher Sale: ${voucher.code}`]);

        // 5. Send SMS (Mock or Real)
        const message = `Code: ${voucher.code}. Package: ${pkg.name}.`;
        await sendSMS(phone_number, message);

        // 6. Record SMS Log (if table exists, otherwise skip or ensure it does)
        // Assuming sms_logs table exists from previous context or generic logging
        try {
            await connection.query('INSERT INTO sms_logs (recipient, message, status, admin_id) VALUES (?, ?, ?, ?)',
                [phone_number, message, 'sent', req.user.id]);
        } catch (logErr) {
            console.warn('SMS Log skipped:', logErr.message);
        }

        await connection.commit();
        req.io.emit('data_update', { type: 'vouchers' });
        req.io.emit('data_update', { type: 'sms' });
        res.json({ message: 'Voucher sold and sent via SMS', voucher: voucher.code });

    } catch (err) {
        await connection.rollback();
        console.error('Sell Voucher Error:', err);
        res.status(500).json({ error: 'Transaction failed' });
    } finally {
        connection.release();
    }
});

router.delete('/admin/vouchers', async (req, res) => {
    const { ids } = req.body;
    if (!ids || !Array.isArray(ids) || ids.length === 0) {
        return res.status(400).json({ error: 'No IDs provided' });
    }

    try {
        const placeholders = ids.map(() => '?').join(',');
        const [vouchers] = await db.query(`SELECT code FROM vouchers WHERE id IN (${placeholders}) AND admin_id = ?`, [...ids, req.user.id]);

        await db.query(`DELETE FROM vouchers WHERE id IN (${placeholders}) AND admin_id = ?`, [...ids, req.user.id]);

        for (const v of vouchers) {
            deleteVoucherFromRadius(v.code).catch(err => console.error('[RADIUS] Deletion error:', err));
        }

        req.io.emit('data_update', { type: 'vouchers' });
        res.json({ message: `Deleted ${ids.length} vouchers` });
    } catch (err) {
        console.error('Delete Vouchers Error:', err);
        res.status(500).json({ error: 'Failed to delete vouchers: ' + err.message });
    }
});

// --- Transactions / Payments History ---
router.get('/admin/transactions', async (req, res) => {
    try {
        const { router_id } = req.query;
        let query = `
            SELECT t.id, t.transaction_ref, t.phone_number, t.amount, t.status, t.payment_method, t.created_at, p.name as package_name, r.name as router_name
            FROM transactions t
            LEFT JOIN packages p ON t.package_id = p.id
            LEFT JOIN routers r ON t.router_id = r.id
            WHERE t.admin_id = ?
        `;
        const params = [req.user.id];

        if (router_id) {
            query += ' AND t.router_id = ?';
            params.push(router_id);
        }

        query += ' ORDER BY t.created_at DESC LIMIT 500';

        const [rows] = await db.query(query, params);
        res.json(rows);
    } catch (err) {
        console.error('Fetch Transactions Error:', err);
        res.status(500).json({ error: 'Failed to fetch transactions' });
    }
});


// --- Analytics (Graphs) ---
// --- Analytics (Graphs) ---
router.get('/admin/analytics/transactions', async (req, res) => {
    const { period } = req.query; // 'weekly', 'monthly', 'yearly'
    const adminId = req.user.id;
    let query = '';
    let params = [adminId];

    try {
        if (period === 'weekly') {
            // Last 7 days
            query = `
                SELECT DATE_FORMAT(created_at, '%a') as label, SUM(amount) as total_amount, COUNT(*) as count
                FROM transactions
                WHERE admin_id = ? AND status = 'success' AND payment_method != 'manual' 
                AND created_at >= DATE_SUB(CURDATE(), INTERVAL 6 DAY)
            `;
            if (req.query.router_id) {
                query += ' AND router_id = ?';
                params.push(req.query.router_id);
            }
            query += `
                GROUP BY DATE_FORMAT(created_at, '%a')
                ORDER BY MIN(created_at) ASC
            `;
        } else if (period === 'monthly') {
            // Last 30 days
            query = `
                SELECT DATE_FORMAT(created_at, '%d %b') as label, SUM(amount) as total_amount, COUNT(*) as count
                FROM transactions
                WHERE admin_id = ? AND status = 'success' AND payment_method != 'manual'
                AND created_at >= DATE_SUB(CURDATE(), INTERVAL 29 DAY)
            `;
            if (req.query.router_id) {
                query += ' AND router_id = ?';
                params.push(req.query.router_id);
            }
            query += `
                GROUP BY DATE_FORMAT(created_at, '%d %b')
                ORDER BY MIN(created_at) ASC
            `;
        } else if (period === 'yearly') {
            // Last 12 months
            query = `
                SELECT DATE_FORMAT(created_at, '%b %Y') as label, SUM(amount) as total_amount, COUNT(*) as count
                FROM transactions
                WHERE admin_id = ? AND status = 'success' AND payment_method != 'manual'
                AND created_at >= DATE_SUB(CURDATE(), INTERVAL 11 MONTH)
                GROUP BY DATE_FORMAT(created_at, '%b %Y')
                ORDER BY MIN(created_at) ASC
            `;
        } else {
            return res.status(400).json({ error: 'Invalid period' });
        }

        const [rows] = await db.query(query, params);
        res.json(rows);
    } catch (err) {
        console.error('Analytics Error:', err); // Check PM2 logs for this
        res.status(500).json({ error: 'Failed to fetch analytics: ' + err.message });
    }
});

// --- Stats & Logs ---
router.get('/admin/stats', async (req, res) => {
    try {
        const { router_id } = req.query;
        const adminId = req.user.id;

        let whereClause = "WHERE admin_id = ? AND (status = 'success' OR status = 'SUCCESS') AND (transaction_ref NOT LIKE 'SMS-%' AND transaction_ref NOT LIKE 'SUB-%' AND transaction_ref NOT LIKE 'W-%')";
        const params = [adminId];

        if (router_id) {
            whereClause += " AND router_id = ?";
            params.push(router_id);
        }

        const statsQuery = `
            SELECT 
                COALESCE(SUM(CASE WHEN DATE(created_at) = CURDATE() THEN amount ELSE 0 END), 0) as daily_revenue,
                COALESCE(SUM(CASE WHEN YEARWEEK(created_at, 1) = YEARWEEK(CURDATE(), 1) THEN amount ELSE 0 END), 0) as weekly_revenue,
                COALESCE(SUM(CASE WHEN MONTH(created_at) = MONTH(CURDATE()) AND YEAR(created_at) = YEAR(CURDATE()) THEN amount ELSE 0 END), 0) as monthly_revenue,
                COALESCE(SUM(CASE WHEN YEAR(created_at) = YEAR(CURDATE()) THEN amount ELSE 0 END), 0) as yearly_revenue,
                COALESCE(SUM(amount), 0) as total_revenue,
                COALESCE(SUM(amount - COALESCE(fee, 0)), 0) as net_revenue
            FROM transactions
            ${whereClause}
        `;

        const [transStats] = await db.query(statsQuery, params);

        const [withdrawStats] = await db.query('SELECT COALESCE(SUM(amount), 0) as total_withdrawn FROM withdrawals WHERE admin_id = ? AND status != "failed"', [adminId]);

        const grossRevenue = Number(transStats[0].total_revenue);
        const netRevenue = Number(transStats[0].net_revenue);
        const totalWithdrawn = Number(withdrawStats[0].total_withdrawn);
        const netBalance = netRevenue - totalWithdrawn;

        // 2. Counts
        let routerFilter = "";
        let countParams = [adminId];
        if (router_id) {
            routerFilter = " AND router_id = ?";
            countParams.push(router_id);
        }

        const [catCount] = await db.query(`SELECT count(*) as count FROM categories WHERE admin_id = ?${routerFilter}`, countParams);
        const [pkgCount] = await db.query(`SELECT count(*) as count FROM packages WHERE admin_id = ?${routerFilter}`, countParams);
        const [voucherCount] = await db.query(`
            SELECT count(*) as count FROM vouchers v 
            LEFT JOIN packages p ON v.package_id = p.id 
            WHERE (p.admin_id = ? OR v.admin_id = ?) AND (v.is_used = 0 OR v.is_used IS NULL)
        `, [adminId, adminId]);

        const [boughtCount] = await db.query(`
            SELECT count(*) as count FROM transactions 
            WHERE admin_id = ? AND status = 'success' AND transaction_ref NOT LIKE 'SMS-%'${routerFilter}
        `, countParams);

        const [paymentCount] = await db.query(`
            SELECT count(*) as count FROM transactions 
            WHERE admin_id = ? AND status = 'success'${routerFilter}
        `, countParams);

        // 3. SMS Balance & Active Sessions
        const [smsBalRows] = await db.query('SELECT SUM(amount) as balance FROM sms_fees WHERE admin_id = ? AND (status="success" OR status IS NULL)', [adminId]);
        const smsBalance = Number(smsBalRows[0]?.balance || 0);

        const dailyRev = Number(transStats[0]?.daily_revenue || 0);
        const weeklyRev = Number(transStats[0]?.weekly_revenue || 0);
        const monthlyRev = Number(transStats[0]?.monthly_revenue || 0);
        const yearlyRev = Number(transStats[0]?.yearly_revenue || 0);

        // 4. Subscription Status
        const [adminInfo] = await db.query('SELECT subscription_expiry, billing_type FROM admins WHERE id = ?', [adminId]);

        res.json({
            revenue: {
                today: dailyRev,
                this_week: weeklyRev,
                this_month: monthlyRev,
                this_year: yearlyRev,
                total: grossRevenue
            },
            finance: {
                ...transStats[0],
                total_balance: grossRevenue,
                gross_revenue: grossRevenue,
                net_balance: netBalance > 0 ? netBalance : 0
            },
            sms_balance: smsBalance > 0 ? smsBalance : 0,
            counts: {
                categories_count: catCount[0].count,
                packages_count: pkgCount[0].count,
                vouchers_count: voucherCount[0].count,
                bought_vouchers_count: boughtCount[0].count,
                payments_count: paymentCount[0].count,
                clients: boughtCount[0].count
            },
            subscription: {
                expiry: adminInfo[0]?.subscription_expiry,
                billing_type: adminInfo[0]?.billing_type
            }
        });
    } catch (err) {
        console.error('Stats Error:', err);
        res.status(500).json({ error: 'Failed to fetch stats' });
    }
});

// SMS Balance (Mock or Real)
router.get('/admin/sms-balance', async (req, res) => {
    try {
        // Retrieve balance from Relworx or mocked
        // For now, return 0 or fetch from admins table if column exists.
        // Returning 0 to prevent crash. User can request full implementation later.
        res.json({ balance: 0 });
    } catch (err) {
        res.status(500).json({ error: 'Failed to fetch SMS balance' });
    }
});

// SMS Logs
router.get('/admin/sms-logs', async (req, res) => {
    try {
        const [rows] = await db.query('SELECT * FROM sms_logs WHERE admin_id = ? ORDER BY created_at DESC LIMIT 100', [req.user.id]);
        res.json(rows);
    } catch (err) {
        res.status(500).json({ error: 'Failed to fetch logs' });
    }
});


// --- Subscription Renewal ---
router.post('/admin/renew-subscription', async (req, res) => {
    const { phone_number, months } = req.body;

    if (!phone_number) return res.status(400).json({ error: 'Phone number is required' });
    if (!months || months < 1) return res.status(400).json({ error: 'Invalid duration' });

    // Enforce Pricing Server-Side
    const MONTHLY_FEE = 20000;
    const amount = months * MONTHLY_FEE;

    try {
        // Format Phone
        let formattedPhone = phone_number.trim();
        if (formattedPhone.startsWith('0')) formattedPhone = '+256' + formattedPhone.slice(1);
        else if (!formattedPhone.startsWith('+')) formattedPhone = '+' + formattedPhone;

        const reference = `SUB - ${Date.now()} -${Math.floor(Math.random() * 1000)} `;

        console.log(`[SUBSCRIPTION] Initiating for ${formattedPhone}, Months: ${months}, Amount: ${amount}, Ref: ${reference} `);

        // 1. Insert Pending Record in NEW table
        await db.query(`
            INSERT INTO admin_subscriptions
            (admin_id, amount, months, phone_number, status, reference)
        VALUES(?, ?, ?, ?, 'pending', ?)
        `, [req.user.id, amount, months, formattedPhone, reference]);

        // 2. Call Relworx
        const response = await fetch(RELWORX_API_URL, {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json',
                'Accept': 'application/vnd.relworx.v2',
                'Authorization': `Bearer ${RELWORX_API_KEY} `
            },
            body: JSON.stringify({
                account_no: RELWORX_ACCOUNT_NO,
                reference: reference,
                msisdn: formattedPhone,
                currency: 'UGX',
                amount: Number(amount),
                description: `Subscription Renewal(${months} months)`
            })
        });

        const paymentData = await response.json();
        console.log(`[SUBSCRIPTION] Gateway Response: `, JSON.stringify(paymentData));

        if (response.ok) {
            res.json({
                message: 'Payment request initiated.',
                status: 'pending',
                reference: reference
            });
        } else {
            console.error(`[SUBSCRIPTION] Gateway Failed: `, paymentData);
            await db.query('UPDATE admin_subscriptions SET status = "failed" WHERE reference = ?', [reference]);
            res.status(400).json({ error: 'Payment gateway failed', details: paymentData });
        }
    } catch (err) {
        console.error('Subscription Error:', err);
        res.status(500).json({ error: 'Failed to process subscription' });
    }
});

router.get('/admin/subscription-status/:reference', async (req, res) => {
    try {
        const [rows] = await db.query('SELECT status, months FROM admin_subscriptions WHERE reference = ? AND admin_id = ?', [req.params.reference, req.user.id]);
        if (rows.length === 0) return res.status(404).json({ error: 'Transaction not found' });

        const localStatus = rows[0].status;
        const monthsToAdd = rows[0].months;

        if (localStatus === 'success' || localStatus === 'failed') {
            return res.json({ status: localStatus });
        }

        // Poll Gateway
        const checkUrl = `https://payments.relworx.com/api/mobile-money/check-request-status?account_no=${RELWORX_ACCOUNT_NO}&reference=${req.params.reference}&internal_reference=${req.params.reference}`;

        console.log(`[SUBSCRIPTION-POLL] Checking: ${req.params.reference}`);

        const gwRes = await fetch(checkUrl, {
            method: 'GET',
            headers: {
                'Accept': 'application/vnd.relworx.v2',
                'Authorization': `Bearer ${RELWORX_API_KEY}`
            }
        });

        if (!gwRes.ok) return res.json({ status: 'pending' });

        const gwData = await gwRes.json();
        const gwStatus = (gwData.status || '').toUpperCase();
        const itemStatus = (gwData.item_status || '').toUpperCase();

        if (gwStatus === 'SUCCESS' || itemStatus === 'SUCCESS') {
            console.log(`[SUBSCRIPTION] Confirmed Success: ${req.params.reference}`);
            await db.query('UPDATE admin_subscriptions SET status = "success" WHERE reference = ?', [req.params.reference]);

            // Update Admin Expiry
            // We need to fetch current expiry first to add time correctly
            const [adminRows] = await db.query('SELECT subscription_expiry FROM admins WHERE id = ?', [req.user.id]);
            let currentExpiry = new Date(adminRows[0].subscription_expiry);
            const now = new Date();

            // If expired, start from NOW. If active, add to current expiry.
            if (currentExpiry < now) currentExpiry = now;

            currentExpiry.setMonth(currentExpiry.getMonth() + monthsToAdd);

            await db.query('UPDATE admins SET subscription_expiry = ? WHERE id = ?', [currentExpiry, req.user.id]);

            return res.json({ status: 'success' });
        } else if (gwStatus === 'FAILED') {
            await db.query('UPDATE admin_subscriptions SET status = "failed" WHERE reference = ?', [req.params.reference]);
            return res.json({ status: 'failed' });
        }

        res.json({ status: 'pending' });

    } catch (err) {
        console.error('Check Subscription Status Error:', err);
        res.status(500).json({ error: 'Failed to check status' });
    }
});

// --- Web Configs (Branding) ---
router.get('/admin/web-configs', async (req, res) => {
    try {
        const [rows] = await db.query('SELECT portal_dns, portal_welcome_msg, terms_text, portal_logo FROM admins WHERE id = ?', [req.user.id]);
        if (rows.length === 0) return res.status(404).json({ error: 'User not found' });
        res.json(rows[0]);
    } catch (err) {
        console.error('Web Configs Error:', err);
        res.status(500).json({ error: 'Failed to fetch web configs' });
    }
});

router.put('/admin/web-configs', async (req, res) => {
    const { portal_dns, portal_welcome_msg, terms_text } = req.body;
    try {
        await db.query(
            'UPDATE admins SET portal_dns = ?, portal_welcome_msg = ?, terms_text = ? WHERE id = ?',
            [portal_dns || null, portal_welcome_msg || null, terms_text || null, req.user.id]
        );
        res.json({ message: 'Web configs updated' });
    } catch (err) {
        console.error('Update Web Configs Error:', err);
        if (err.code === 'ER_DUP_ENTRY') {
             return res.status(400).json({ error: 'Domain already taken' });
        }
        res.status(500).json({ error: 'Failed to update web configs' });
    }
});

router.post('/admin/web-configs/logo', upload.single('file'), async (req, res) => {
    if (!req.file) return res.status(400).json({ error: 'No file uploaded' });
    try {
        const ext = path.extname(req.file.originalname);
        const newName = `logo_${req.user.id}_${Date.now()}${ext}`;
        // Multer dest is 'uploads/', __dirname is src/routes.
        const newPath = path.join(__dirname, '../../uploads', newName);
        fs.renameSync(req.file.path, newPath);
        
        const logo_url = `/uploads/${newName}`;
        await db.query('UPDATE admins SET portal_logo = ? WHERE id = ?', [logo_url, req.user.id]);
        
        res.json({ logo_url });
    } catch (err) {
        console.error('Upload Logo Error:', err);
        res.status(500).json({ error: 'Failed to upload logo' });
    }
});

// --- Portal Ads ---
router.get('/admin/portal-ads', async (req, res) => {
    try {
        const [rows] = await db.query(
            'SELECT * FROM portal_ads WHERE admin_id = ? ORDER BY created_at DESC',
            [req.user.id]
        );
        res.json(rows);
    } catch (err) {
        console.error('Fetch Portal Ads Error:', err);
        res.status(500).json({ error: 'Failed to fetch portal ads' });
    }
});

router.post('/admin/portal-ads/upload', upload.single('file'), async (req, res) => {
    const { title, link_url } = req.body;
    if (!req.file) return res.status(400).json({ error: 'No file uploaded' });
    if (!title) return res.status(400).json({ error: 'Title is required' });

    try {
        const ext = path.extname(req.file.originalname);
        const newName = `ad_${req.user.id}_${Date.now()}${ext}`;
        const newPath = path.join(__dirname, '../../uploads', newName);
        fs.renameSync(req.file.path, newPath);

        const image_url = `/uploads/${newName}`;
        const [result] = await db.query(
            'INSERT INTO portal_ads (admin_id, title, image_url, link_url, is_active) VALUES (?, ?, ?, ?, 1)',
            [req.user.id, title, image_url, link_url || null]
        );

        res.json({
            id: result.insertId,
            title,
            image_url,
            link_url: link_url || null,
            is_active: true,
            message: 'Portal ad uploaded successfully'
        });
    } catch (err) {
        console.error('Upload Portal Ad Error:', err);
        res.status(500).json({ error: 'Failed to upload portal ad' });
    }
});

router.patch('/admin/portal-ads/:id/toggle', async (req, res) => {
    try {
        const [rows] = await db.query(
            'SELECT is_active FROM portal_ads WHERE id = ? AND admin_id = ?',
            [req.params.id, req.user.id]
        );
        if (rows.length === 0) return res.status(404).json({ error: 'Ad not found' });

        const newState = rows[0].is_active ? 0 : 1;
        await db.query(
            'UPDATE portal_ads SET is_active = ? WHERE id = ?',
            [newState, req.params.id]
        );

        res.json({ is_active: newState, message: 'Ad status updated successfully' });
    } catch (err) {
        console.error('Toggle Portal Ad Error:', err);
        res.status(500).json({ error: 'Failed to toggle ad status' });
    }
});

router.delete('/admin/portal-ads/:id', async (req, res) => {
    try {
        const [rows] = await db.query(
            'SELECT image_url FROM portal_ads WHERE id = ? AND admin_id = ?',
            [req.params.id, req.user.id]
        );
        if (rows.length === 0) return res.status(404).json({ error: 'Ad not found' });

        const imagePath = path.join(__dirname, '../..', rows[0].image_url);
        fs.unlink(imagePath, (err) => {
            if (err) console.warn('Could not delete image file:', err.message);
        });

        await db.query(
            'DELETE FROM portal_ads WHERE id = ? AND admin_id = ?',
            [req.params.id, req.user.id]
        );

        res.json({ message: 'Portal ad deleted successfully' });
    } catch (err) {
        console.error('Delete Portal Ad Error:', err);
        res.status(500).json({ error: 'Failed to delete portal ad' });
    }
});

// --- Agent Management for Admin ---
router.get('/admin/agents', async (req, res) => {
    try {
        const adminId = req.user.id;
        const [agents] = await db.query(`
            SELECT 
                a.id, a.username, a.phone_number, a.created_at,
                COALESCE(v.stock_count, 0) as stock_count,
                COALESCE(t.total_sales, 0) as total_sales,
                COALESCE(u.unsettled_amount, 0) as unsettled_amount
            FROM agents a
            LEFT JOIN (
                SELECT agent_id, COUNT(*) as stock_count 
                FROM vouchers 
                WHERE (is_used = 0 OR is_used IS NULL) 
                GROUP BY agent_id
            ) v ON a.id = v.agent_id
            LEFT JOIN (
                SELECT agent_id, SUM(amount) as total_sales 
                FROM transactions 
                WHERE status = 'success' 
                GROUP BY agent_id
            ) t ON a.id = t.agent_id
            LEFT JOIN (
                SELECT agent_id, SUM(amount) as unsettled_amount 
                FROM transactions 
                WHERE status = 'success' AND (is_settled = 0 OR is_settled IS NULL)
                GROUP BY agent_id
            ) u ON a.id = u.agent_id
            WHERE a.admin_id = ?
            ORDER BY a.created_at DESC
        `, [adminId]);

        res.json(agents);
    } catch (err) {
        console.error('Fetch Admin Agents Error:', err);
        res.status(500).json({ error: 'Failed to fetch agents' });
    }
});

router.post('/admin/agents', async (req, res) => {
    const { username, password, phone_number } = req.body;
    if (!username || !password) return res.status(400).json({ error: 'Username and password required' });

    try {
        const [existing] = await db.query('SELECT id FROM agents WHERE username = ?', [username]);
        if (existing.length > 0) return res.status(400).json({ error: 'Username already taken' });

        const salt = await bcrypt.genSalt(10);
        const hash = await bcrypt.hash(password, salt);

        await db.query(
            'INSERT INTO agents (admin_id, username, password_hash, phone_number) VALUES (?, ?, ?, ?)',
            [req.user.id, username, hash, phone_number || null]
        );

        req.io.emit('data_update', { type: 'agents' });
        res.status(201).json({ message: 'Agent created successfully' });
    } catch (err) {
        console.error('Create Agent Error:', err);
        res.status(500).json({ error: 'Failed to create agent' });
    }
});

module.exports = router;
