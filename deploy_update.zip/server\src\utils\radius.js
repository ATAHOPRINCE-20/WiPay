/**
 * RADIUS Database Sync Utilities
 * Syncs vouchers to FreeRADIUS database for Mikrotik hotspot authentication
 */

const db = require('../config/db');

/**
 * Sync a single voucher to RADIUS database
 * Creates entries in radcheck (password) and radreply (rate limit, session timeout)
 * 
 * @param {string} voucherCode - The voucher/username
 * @param {number} packageId - Package ID to fetch rate limit and validity
 * @returns {Promise<boolean>} True if sync successful
 */
async function syncVoucherToRadius(voucherCode, packageId) {
    try {
        const connection = await db.getConnection();

        try {
            // Clean old conflicting User-Password attribute if present
            await connection.query(`DELETE FROM radcheck WHERE username = ? AND attribute = 'User-Password'`, [voucherCode]);

            // 1. Insert/Update single Cleartext-Password attribute in radcheck (standard for FreeRADIUS PAP/CHAP)
            await connection.query(`
                INSERT INTO radcheck (username, attribute, op, value)
                VALUES (?, 'Cleartext-Password', ':=', ?)
                ON DUPLICATE KEY UPDATE value = VALUES(value)
            `, [voucherCode, voucherCode]);

            // Lowercase fallback for case-insensitive matching
            if (voucherCode !== voucherCode.toLowerCase()) {
                await connection.query(`
                    INSERT INTO radcheck (username, attribute, op, value)
                    VALUES (?, 'Cleartext-Password', ':=', ?)
                    ON DUPLICATE KEY UPDATE value = VALUES(value)
                `, [voucherCode.toLowerCase(), voucherCode]);
            }

            console.log(`[RADIUS] Synced password for voucher: ${voucherCode}`);

            // 2. Fetch package details for rate limit, validity, and simultaneous devices
            const [packages] = await connection.query(
                'SELECT rate_limit, validity_hours, validity_minutes, validity_unit, simultaneous_devices FROM packages WHERE id = ?',
                [packageId]
            );

            if (packages.length === 0) {
                console.warn(`[RADIUS] Package ${packageId} not found for voucher ${voucherCode}`);
                return true; // Still mark as synced; package might be deleted
            }

            const pkg = packages[0];

            // 3. Set rate limit (MikroTik-specific attribute)
            // Format: "1M/1M" means 1Mbps upload / 1Mbps download
            if (pkg.rate_limit) {
                await connection.query(`
                    INSERT INTO radreply (username, attribute, op, value)
                    VALUES (?, 'Mikrotik-Rate-Limit', '=', ?)
                    ON DUPLICATE KEY UPDATE value = VALUES(value)
                `, [voucherCode, pkg.rate_limit]);

                console.log(`[RADIUS] Set rate limit for ${voucherCode}: ${pkg.rate_limit}`);
            }

            // 4. Set session timeout & expiration (supports dynamic remaining time)
            let sessionSeconds = 0;
            if (pkg.validity_unit === 'minutes' && pkg.validity_minutes && pkg.validity_minutes > 0) {
                sessionSeconds = pkg.validity_minutes * 60;
            } else if (pkg.validity_hours && pkg.validity_hours > 0) {
                sessionSeconds = pkg.validity_hours * 3600;
            } else if (pkg.validity_minutes && pkg.validity_minutes > 0) {
                sessionSeconds = pkg.validity_minutes * 60;
            }

            // Check if voucher has already been used and has an expiration date
            const [voucherDetails] = await connection.query(
                'SELECT first_used_at, expires_at FROM vouchers WHERE code = ?',
                [voucherCode]
            );

            let isExpired = false;
            let effectiveTimeout = sessionSeconds;

            if (voucherDetails.length > 0 && voucherDetails[0].expires_at) {
                const expiresAt = new Date(voucherDetails[0].expires_at);
                const now = new Date();
                const remainingSecs = Math.floor((expiresAt - now) / 1000);

                if (remainingSecs <= 0) {
                    isExpired = true;
                    console.log(`[RADIUS] Voucher ${voucherCode} has expired on ${expiresAt.toISOString()}. Rejecting RADIUS auth.`);
                } else {
                    effectiveTimeout = remainingSecs;
                    // Format for RADIUS Expiration attribute (e.g., "05 Aug 2026 12:30:00")
                    const monthNames = ["Jan", "Feb", "Mar", "Apr", "May", "Jun", "Jul", "Aug", "Sep", "Oct", "Nov", "Dec"];
                    const expStr = `${String(expiresAt.getDate()).padStart(2, '0')} ${monthNames[expiresAt.getMonth()]} ${expiresAt.getFullYear()} ${String(expiresAt.getHours()).padStart(2, '0')}:${String(expiresAt.getMinutes()).padStart(2, '0')}:${String(expiresAt.getSeconds()).padStart(2, '0')}`;

                    await connection.query(`
                        INSERT INTO radcheck (username, attribute, op, value)
                        VALUES (?, 'Expiration', ':=', ?)
                        ON DUPLICATE KEY UPDATE value = VALUES(value)
                    `, [voucherCode, expStr]);
                }
            }

            if (isExpired) {
                // Deny login by removing Password from radcheck
                await connection.query(`DELETE FROM radcheck WHERE username = ? AND attribute = 'Cleartext-Password'`, [voucherCode]);
                await connection.query(`DELETE FROM radreply WHERE username = ? AND attribute = 'Session-Timeout'`, [voucherCode]);
                return false;
            }

            if (effectiveTimeout > 0) {
                await connection.query(`
                    INSERT INTO radreply (username, attribute, op, value)
                    VALUES (?, 'Session-Timeout', ':=', ?)
                    ON DUPLICATE KEY UPDATE value = VALUES(value)
                `, [voucherCode, effectiveTimeout.toString()]);

                console.log(`[RADIUS] Set session timeout for ${voucherCode}: ${effectiveTimeout}s`);
            }

            // 5. Set simultaneous devices limit (Simultaneous-Use in radcheck)
            if (pkg.simultaneous_devices && pkg.simultaneous_devices > 0) {
                await connection.query(`
                    INSERT INTO radcheck (username, attribute, op, value)
                    VALUES (?, 'Simultaneous-Use', ':=', ?)
                    ON DUPLICATE KEY UPDATE value = VALUES(value)
                `, [voucherCode, pkg.simultaneous_devices.toString()]);

                console.log(`[RADIUS] Set Simultaneous-Use for ${voucherCode}: ${pkg.simultaneous_devices}`);
            }

            return true;

        } finally {
            connection.release();
        }

    } catch (err) {
        console.error(`[RADIUS] Sync Error for voucher ${voucherCode}:`, err);
        return false;
    }
}

/**
 * Sync multiple vouchers to RADIUS in batch
 */
async function syncBatchVouchersToRadius(vouchers) {
    let successCount = 0;

    for (const voucher of vouchers) {
        const success = await syncVoucherToRadius(voucher.code, voucher.packageId);
        if (success) successCount++;
    }

    console.log(`[RADIUS] Batch sync complete: ${successCount}/${vouchers.length} vouchers synced`);
    return successCount;
}

/**
 * Remove a voucher from RADIUS database
 */
async function deleteVoucherFromRadius(voucherCode) {
    try {
        const connection = await db.getConnection();

        try {
            await connection.query('DELETE FROM radcheck WHERE username = ?', [voucherCode]);
            await connection.query('DELETE FROM radreply WHERE username = ?', [voucherCode]);
            await connection.query('DELETE FROM radusergroup WHERE username = ?', [voucherCode]);

            console.log(`[RADIUS] Deleted voucher from RADIUS: ${voucherCode}`);
            return true;

        } finally {
            connection.release();
        }

    } catch (err) {
        console.error(`[RADIUS] Delete Error for voucher ${voucherCode}:`, err);
        return false;
    }
}

/**
 * Check if RADIUS tables exist
 */
async function checkRadiusTablesExist() {
    try {
        const connection = await db.getConnection();

        try {
            const requiredTables = ['radcheck', 'radreply', 'radusergroup', 'radacct', 'nas'];
            
            for (const table of requiredTables) {
                const [rows] = await connection.query(`SHOW TABLES LIKE '${table}'`);
                if (rows.length === 0) {
                    console.warn(`[RADIUS] Missing table: ${table}`);
                    return false;
                }
            }

            console.log('[RADIUS] All required tables found');
            return true;

        } finally {
            connection.release();
        }

    } catch (err) {
        console.error('[RADIUS] Check Tables Error:', err);
        return false;
    }
}

/**
 * Automatically clean up stale RADIUS accounting sessions that were left open
 */
async function cleanupStaleRadiusSessions() {
    try {
        const connection = await db.getConnection();
        try {
            // 1. Close sessions in radacct older than session timeout or 12 hours
            const [result] = await connection.query(`
                UPDATE radacct 
                SET acctstoptime = DATE_ADD(acctstarttime, INTERVAL COALESCE(NULLIF(acctsessiontime, 0), 3600) SECOND),
                    acctterminatecause = 'Session-Timeout'
                WHERE acctstoptime IS NULL 
                  AND TIMESTAMPDIFF(SECOND, acctstarttime, NOW()) > COALESCE(NULLIF(acctsessiontime, 0), 43200)
            `);

            if (result.affectedRows > 0) {
                console.log(`[RADIUS Sweeper] Closed ${result.affectedRows} stale radacct session(s).`);
            }

            // 2. Process vouchers that have passed their expiration date
            const [expiredVouchers] = await connection.query(`
                SELECT code FROM vouchers 
                WHERE is_used = 1 AND expires_at IS NOT NULL AND expires_at < NOW()
            `);

            for (const v of expiredVouchers) {
                await connection.query("DELETE FROM radcheck WHERE username = ? AND attribute = 'Cleartext-Password'", [v.code]);
                await disconnectVoucherSession(v.code);
            }

        } finally {
            connection.release();
        }
    } catch (err) {
        console.error('[RADIUS Sweeper Error]:', err);
    }
}

/**
 * Forcefully disconnect an active user session using MikroTik RouterOS API and RADIUS CoA
 */
async function disconnectVoucherSession(voucherCode) {
    try {
        const connection = await db.getConnection();
        try {
            const [sessions] = await connection.query(
                "SELECT nasipaddress FROM radacct WHERE username = ? AND acctstoptime IS NULL ORDER BY acctstarttime DESC LIMIT 1",
                [voucherCode]
            );

            if (sessions.length === 0) {
                return false;
            }

            const nasIp = sessions[0].nasipaddress;

            // Check if router has API config for direct API disconnect
            const [routerRows] = await connection.query(
                "SELECT ip_address, api_port, api_user, api_password FROM routers WHERE ip_address = ?",
                [nasIp]
            );

            if (routerRows.length > 0) {
                const r = routerRows[0];
                const { disconnectHotspotUser } = require('./mikrotikApi');
                await disconnectHotspotUser({
                    host: r.ip_address,
                    port: r.api_port || 8728,
                    user: r.api_user || 'admin',
                    password: r.api_password || ''
                }, voucherCode).catch(() => false);
            }

            // Also send RADIUS CoA Packet of Disconnect
            const [nas] = await connection.query(
                "SELECT secret FROM nas WHERE nasname = ?",
                [nasIp]
            );

            if (nas.length > 0) {
                const secret = nas[0].secret;
                const { exec } = require('child_process');
                const cmd = `echo "User-Name = ${voucherCode}" | radclient -x ${nasIp}:3799 disconnect ${secret}`;
                
                exec(cmd, (error) => {
                    if (error) {
                        console.error(`[RADIUS CoA] radclient failed for ${voucherCode} on ${nasIp}:`, error.message);
                    } else {
                        console.log(`[RADIUS CoA] Disconnected user ${voucherCode} on NAS ${nasIp}`);
                    }
                });
            }

            // Update radacct stop time
            await connection.query(
                "UPDATE radacct SET acctstoptime = NOW(), acctterminatecause = 'Admin-Reset' WHERE username = ? AND acctstoptime IS NULL",
                [voucherCode]
            );

            return true;

        } finally {
            connection.release();
        }
    } catch (err) {
        console.error(`[RADIUS CoA] Error for ${voucherCode}:`, err);
        return false;
    }
}

module.exports = {
    syncVoucherToRadius,
    syncBatchVouchersToRadius,
    deleteVoucherFromRadius,
    checkRadiusTablesExist,
    cleanupStaleRadiusSessions,
    disconnectVoucherSession
};

