

// validateMobile.js
const path = require('path');
require('dotenv').config({ path: path.join(__dirname, '.env') });

const axios = require('axios');

const API_URL = "https://payments.relworx.com/api/mobile-money/validate";
const API_KEY = process.env.RELWORX_API_KEY;

/**
 * Validates a mobile money number
 * @param {string} msisdn - Phone number in international format (+2567XXXXXXXX)
 */
async function validateMobileNumber(msisdn) {
    if (!API_KEY) {
        throw new Error("RELWORX_API_KEY is not defined in environment variables");
    }

    try {
        const response = await axios.post(API_URL, {
            msisdn: msisdn.replace('+', '') // Normalize: remove + for Relworx
        }, {
            headers: {
                "Content-Type": "application/json",
                "Accept": "application/vnd.relworx.v2",
                "Authorization": `Bearer ${API_KEY}`
            }
        });

        const data = response.data;
        console.log("Validation Success:", data);
        return data;

    } catch (error) {
        console.error("Validation Failed:", error.response ? JSON.stringify(error.response.data) : error.message);
        throw error;
    }
}

module.exports = { validateMobileNumber };
