import { createContext, useContext, useState, useEffect } from 'react'
import api from '../services/api'

const AuthContext = createContext(null)

export function AuthProvider({ children }) {
  const [admin, setAdmin]   = useState(() => {
    const saved = localStorage.getItem('wipay_admin')
    return saved ? JSON.parse(saved) : null
  })
  const [loading, setLoading] = useState(false)
  const [booting, setBooting] = useState(() => {
    const hasToken = !!localStorage.getItem('wipay_token')
    const hasAdmin = !!localStorage.getItem('wipay_admin')
    return hasToken && !hasAdmin
  })

  useEffect(() => {
    const token = localStorage.getItem('wipay_token')
    if (!token) { setBooting(false); return }
    api.get('/auth/profile')
      .then(({ data }) => {
        setAdmin(data)
        localStorage.setItem('wipay_admin', JSON.stringify(data))
      })
      .catch((err) => {
        if (err.response?.status === 401 || err.response?.status === 403) {
          localStorage.removeItem('wipay_token')
          localStorage.removeItem('wipay_admin')
          setAdmin(null)
        }
      })
      .finally(() => setBooting(false))
  }, [])

  const login = async (username, password) => {
    setLoading(true)
    try {
      const { data } = await api.post('/auth/login', { username, password })
      localStorage.setItem('wipay_token', data.token)
      localStorage.setItem('wipay_admin', JSON.stringify(data.admin))
      setAdmin(data.admin)
      return { ok: true, admin: data.admin, role: data.role }
    } catch (err) {
      return { ok: false, message: err.response?.data?.message || err.response?.data?.error || 'Login failed.' }
    } finally {
      setLoading(false)
    }
  }

  const logout = async () => {
    try { await api.post('/auth/logout') } catch (_) {}
    localStorage.removeItem('wipay_token')
    localStorage.removeItem('wipay_admin')
    localStorage.removeItem('wipay_super_admin_backup')
    setAdmin(null)
  }

  const impersonateTenant = async (tenantId) => {
    const currentToken = localStorage.getItem('wipay_token')
    const currentAdmin = localStorage.getItem('wipay_admin')
    if (!localStorage.getItem('wipay_super_admin_backup') && currentToken && currentAdmin) {
      localStorage.setItem('wipay_super_admin_backup', JSON.stringify({ token: currentToken, admin: JSON.parse(currentAdmin) }))
    }

    const { data } = await api.post(`/super/tenants/${tenantId}/impersonate`)
    localStorage.setItem('wipay_token', data.token)
    localStorage.setItem('wipay_admin', JSON.stringify(data.admin))
    setAdmin(data.admin)
    return data.admin
  }

  const exitImpersonation = () => {
    const backupStr = localStorage.getItem('wipay_super_admin_backup')
    if (backupStr) {
      try {
        const backup = JSON.parse(backupStr)
        localStorage.setItem('wipay_token', backup.token)
        localStorage.setItem('wipay_admin', JSON.stringify(backup.admin))
        localStorage.removeItem('wipay_super_admin_backup')
        setAdmin(backup.admin)
        window.location.href = '/super-admin'
      } catch (_) {}
    }
  }

  const isImpersonating = !!localStorage.getItem('wipay_super_admin_backup')

  const refreshProfile = async () => {
    try {
      const { data } = await api.get('/auth/profile')
      setAdmin(data)
      localStorage.setItem('wipay_admin', JSON.stringify(data))
    } catch (_) {}
  }

  return (
    <AuthContext.Provider value={{ admin, loading, booting, login, logout, refreshProfile, impersonateTenant, exitImpersonation, isImpersonating }}>
      {children}
    </AuthContext.Provider>
  )
}

export const useAuth = () => useContext(AuthContext)
