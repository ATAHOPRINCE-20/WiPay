System.register(["./index-legacy-BK-hIRyp.js"],function(e,t){"use strict";var r;return{setters:[function(e){r=e.c}],execute:function(){
/**
       * @license lucide-react v0.447.0 - ISC
       *
       * This source code is licensed under the ISC license.
       * See the LICENSE file in the root directory of this source tree.
       */
e("A",r("ArrowRight",[["path",{d:"M5 12h14",key:"1ays0h"}],["path",{d:"m12 5 7 7-7 7",key:"xquz4c"}]]))}}});
