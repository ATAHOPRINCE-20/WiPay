System.register(["./index-legacy-BK-hIRyp.js"],function(e,t){"use strict";var s;return{setters:[function(e){s=e.c}],execute:function(){
/**
       * @license lucide-react v0.447.0 - ISC
       *
       * This source code is licensed under the ISC license.
       * See the LICENSE file in the root directory of this source tree.
       */
e("M",s("MessageSquare",[["path",{d:"M21 15a2 2 0 0 1-2 2H7l-4 4V5a2 2 0 0 1 2-2h14a2 2 0 0 1 2 2z",key:"1lielz"}]]))}}});
